#!/bin/sh
# Compila e executa o AutoFix (precisa do JDK instalado)
mkdir -p out
javac -encoding UTF-8 -d out $(find src -name "*.java") && java -cp out autofix.Main
