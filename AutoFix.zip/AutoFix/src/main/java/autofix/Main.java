package autofix;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.sql.SQLException;

/** Ponto de partida do programa: é aqui que tudo começa. */
public class Main {

    public static void main(String[] args) {
        // 1) Cria o banco e as tabelas (se ainda não existirem)
        try {
            Banco.criarBanco();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Não foi possível conectar ao MySQL (localhost:3306, usuário root).\n"
                    + "Verifique se o MySQL está ligado e se a senha está correta.\n\n" + e.getMessage(),
                    "Erro de conexão", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2) Abre a janela
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // se falhar, usa o visual padrão
            }
            new TelaPrincipal().setVisible(true);
        });
    }
}
