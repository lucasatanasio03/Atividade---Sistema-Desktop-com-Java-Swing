package autofix;

import javax.swing.JPanel;

/** Toda tela (aba) do sistema é um JPanel com um método atualizar(), chamado ao abrir a aba. */
public abstract class Tela extends JPanel {

    /** Recarrega os dados do banco. */
    public abstract void atualizar();
}
