package autofix;

/** Uma peça usada dentro de uma ordem de serviço. */
public class ItemOS {
    public int id;
    public String codigo;
    public String descricao;
    public int quantidade;
    public double valorUnitario;

    public double subtotal() {
        return quantidade * valorUnitario;
    }
}
