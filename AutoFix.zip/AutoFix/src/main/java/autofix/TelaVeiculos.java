package autofix;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Aba de veículos. */
public class TelaVeiculos extends Tela {

    private JComboBox<Cliente> comboCliente = new JComboBox<>();
    private JTextField campoPlaca = new JTextField(25);
    private JTextField campoModelo = new JTextField(25);
    private JTextField campoAno = new JTextField(25);
    private JTextField campoBusca = new JTextField(20);

    private DefaultTableModel modelo = Util.modelo("Placa", "Modelo", "Ano", "Cliente");
    private JTable tabela = new JTable(modelo);

    private List<Veiculo> lista = new ArrayList<>();
    private Veiculo selecionado = null;

    public TelaVeiculos() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        Util.campo(formulario, "Cliente (dono):", comboCliente);
        Util.campo(formulario, "Placa:", campoPlaca);
        Util.campo(formulario, "Modelo:", campoModelo);
        Util.campo(formulario, "Ano:", campoAno);

        JButton botaoSalvar = new JButton("Salvar");
        JButton botaoNovo = new JButton("Novo");
        JButton botaoExcluir = new JButton("Excluir");
        botaoSalvar.addActionListener(e -> salvar());
        botaoNovo.addActionListener(e -> limpar());
        botaoExcluir.addActionListener(e -> excluir());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botoes.add(botaoSalvar);
        botoes.add(botaoNovo);
        botoes.add(botaoExcluir);

        JPanel topo = new JPanel(new BorderLayout(0, 8));
        JPanel formularioAlinhado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formularioAlinhado.add(formulario);
        topo.add(formularioAlinhado, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);
        add(topo, BorderLayout.NORTH);

        JButton botaoBuscar = new JButton("Buscar");
        botaoBuscar.addActionListener(e -> atualizar());
        campoBusca.addActionListener(e -> atualizar());
        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        busca.add(new JLabel("Buscar (placa, modelo ou cliente):"));
        busca.add(campoBusca);
        busca.add(botaoBuscar);

        JPanel centro = new JPanel(new BorderLayout(0, 5));
        centro.add(busca, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (!e.getValueIsAdjusting() && linha >= 0) {
                selecionado = lista.get(linha);
                campoPlaca.setText(selecionado.placa);
                campoModelo.setText(selecionado.modelo);
                campoAno.setText(String.valueOf(selecionado.ano));
                for (int i = 0; i < comboCliente.getItemCount(); i++) {
                    if (comboCliente.getItemAt(i).id == selecionado.clienteId) {
                        comboCliente.setSelectedIndex(i);
                    }
                }
            }
        });

        atualizar();
    }

    @Override
    public void atualizar() {
        try {
            comboCliente.removeAllItems();
            for (Cliente c : ClienteDAO.listar("")) {
                comboCliente.addItem(c);
            }
            lista = VeiculoDAO.listar(campoBusca.getText());
            modelo.setRowCount(0);
            for (Veiculo v : lista) {
                modelo.addRow(new Object[]{v.placa, v.modelo, v.ano, v.clienteNome});
            }
            selecionado = null;
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void limpar() {
        tabela.clearSelection();
        selecionado = null;
        campoPlaca.setText("");
        campoModelo.setText("");
        campoAno.setText("");
    }

    private void salvar() {
        try {
            Cliente dono = (Cliente) comboCliente.getSelectedItem();
            if (dono == null) {
                throw new IllegalArgumentException("Cadastre um cliente antes de cadastrar o veículo.");
            }
            if (campoPlaca.getText().trim().isEmpty() || campoModelo.getText().trim().isEmpty()) {
                throw new IllegalArgumentException("Informe a placa e o modelo.");
            }
            int ano = Util.inteiro(campoAno.getText());
            if (ano < 1900 || ano > 2100) {
                throw new IllegalArgumentException("Ano inválido.");
            }

            Veiculo v = new Veiculo();
            v.clienteId = dono.id;
            v.placa = campoPlaca.getText().trim().toUpperCase();
            v.modelo = campoModelo.getText().trim();
            v.ano = ano;

            if (selecionado == null) {
                VeiculoDAO.inserir(v);
            } else {
                v.id = selecionado.id;
                VeiculoDAO.atualizar(v);
            }
            limpar();
            atualizar();
            Util.aviso(this, "Veículo salvo com sucesso!");
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void excluir() {
        if (selecionado == null) {
            Util.aviso(this, "Clique em um veículo da lista para excluir.");
            return;
        }
        if (!Util.confirmar(this, "Excluir o veículo " + selecionado.placa + "?")) {
            return;
        }
        try {
            VeiculoDAO.excluir(selecionado.id);
            limpar();
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }
}
