package autofix;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Comandos SQL da tabela cliente. */
public class ClienteDAO {

    public static List<Cliente> listar(String busca) throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM cliente WHERE nome LIKE ? OR cpf LIKE ? OR telefone LIKE ? ORDER BY nome";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            String texto = "%" + busca.trim() + "%";
            ps.setString(1, texto);
            ps.setString(2, texto);
            ps.setString(3, texto);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.id = rs.getInt("id");
                cli.nome = rs.getString("nome");
                cli.cpf = rs.getString("cpf");
                cli.telefone = rs.getString("telefone");
                lista.add(cli);
            }
        }
        return lista;
    }

    public static void inserir(Cliente cli) throws SQLException {
        String sql = "INSERT INTO cliente (nome, cpf, telefone) VALUES (?, ?, ?)";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, cli.nome);
            ps.setString(2, cli.cpf);
            ps.setString(3, cli.telefone);
            ps.executeUpdate();
        }
    }

    public static void atualizar(Cliente cli) throws SQLException {
        String sql = "UPDATE cliente SET nome = ?, cpf = ?, telefone = ? WHERE id = ?";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, cli.nome);
            ps.setString(2, cli.cpf);
            ps.setString(3, cli.telefone);
            ps.setInt(4, cli.id);
            ps.executeUpdate();
        }
    }

    public static void excluir(int id) throws SQLException {
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement("DELETE FROM cliente WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
