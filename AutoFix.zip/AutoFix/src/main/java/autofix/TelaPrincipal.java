package autofix;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.Dimension;

/** Janela principal: uma aba para cada parte do sistema. */
public class TelaPrincipal extends JFrame {

    public TelaPrincipal() {
        setTitle("AutoFix - Gestão de Oficina Mecânica");
        setSize(1000, 700);
        setMinimumSize(new Dimension(900, 600));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane abas = new JTabbedPane();
        abas.addTab("Clientes", new TelaClientes());
        abas.addTab("Veículos", new TelaVeiculos());
        abas.addTab("Estoque", new TelaEstoque());
        abas.addTab("Ordens de Serviço", new TelaOrdens());
        abas.addTab("Faturamento", new TelaFaturamento());

        // Sempre que mudar de aba, recarrega os dados dela
        abas.addChangeListener(e -> ((Tela) abas.getSelectedComponent()).atualizar());

        add(abas);
    }
}
