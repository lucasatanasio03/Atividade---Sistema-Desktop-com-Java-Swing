package autofix;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Cuida da conexão com o MySQL e da criação das tabelas. */
public class Banco {

    // >>> Se precisar mudar usuário/senha, é só aqui <<<
    private static final String SERVIDOR = "jdbc:mysql://localhost:3306/";
    private static final String USUARIO = "root";
    private static final String SENHA = "lucas";
    private static final String OPCOES = "?useSSL=false&allowPublicKeyRetrieval=true"
            + "&characterEncoding=UTF-8&serverTimezone=America/Sao_Paulo";

    /** Abre uma conexão com o banco "autofix". */
    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(SERVIDOR + "autofix" + OPCOES, USUARIO, SENHA);
    }

    /** Cria o banco, as tabelas e (se estiver vazio) os dados de exemplo. */
    public static void criarBanco() throws SQLException {
        try (Connection c = DriverManager.getConnection(SERVIDOR + OPCOES, USUARIO, SENHA);
             Statement st = c.createStatement()) {
            st.execute("CREATE DATABASE IF NOT EXISTS autofix CHARACTER SET utf8mb4");
        }

        try (Connection c = conectar(); Statement st = c.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS cliente ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "nome VARCHAR(100) NOT NULL, "
                    + "cpf VARCHAR(20) UNIQUE, "
                    + "telefone VARCHAR(20))");

            st.execute("CREATE TABLE IF NOT EXISTS veiculo ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "cliente_id INT NOT NULL, "
                    + "placa VARCHAR(10) NOT NULL UNIQUE, "
                    + "modelo VARCHAR(60) NOT NULL, "
                    + "ano INT, "
                    + "FOREIGN KEY (cliente_id) REFERENCES cliente(id))");

            st.execute("CREATE TABLE IF NOT EXISTS peca ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "codigo VARCHAR(20) NOT NULL UNIQUE, "
                    + "descricao VARCHAR(100) NOT NULL, "
                    + "quantidade INT NOT NULL DEFAULT 0, "
                    + "minimo INT NOT NULL DEFAULT 0, "
                    + "preco DECIMAL(10,2) NOT NULL)");

            // As OS começam no número 1037
            st.execute("CREATE TABLE IF NOT EXISTS ordem_servico ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "veiculo_id INT NOT NULL, "
                    + "mecanico VARCHAR(60), "
                    + "problema VARCHAR(255), "
                    + "mao_de_obra DECIMAL(10,2) NOT NULL DEFAULT 0, "
                    + "status VARCHAR(10) NOT NULL DEFAULT 'ABERTA', "
                    + "desconto DECIMAL(10,2) NOT NULL DEFAULT 0, "
                    + "forma_pagamento VARCHAR(30), "
                    + "data_abertura DATE NOT NULL, "
                    + "FOREIGN KEY (veiculo_id) REFERENCES veiculo(id)) AUTO_INCREMENT = 1037");

            // Peças usadas em cada OS (guarda o preço da hora da venda)
            st.execute("CREATE TABLE IF NOT EXISTS item_os ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "os_id INT NOT NULL, "
                    + "peca_id INT NOT NULL, "
                    + "quantidade INT NOT NULL, "
                    + "valor_unitario DECIMAL(10,2) NOT NULL, "
                    + "FOREIGN KEY (os_id) REFERENCES ordem_servico(id) ON DELETE CASCADE, "
                    + "FOREIGN KEY (peca_id) REFERENCES peca(id))");

            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM cliente");
            rs.next();
            if (rs.getInt(1) == 0) {
                inserirDadosExemplo(st);
            }
        }
    }

    private static void inserirDadosExemplo(Statement st) throws SQLException {
        st.execute("INSERT INTO cliente (nome, cpf, telefone) VALUES "
                + "('Carlos Eduardo Silva', '123.456.789-00', '(47) 99123-4567'), "
                + "('Marina Souza Lima', '987.654.321-00', '(47) 99876-1122'), "
                + "('Transportes Norte Ltda', '12.345.678/0001-90', '(47) 3422-5566')");

        st.execute("INSERT INTO veiculo (cliente_id, placa, modelo, ano) VALUES "
                + "(1, 'ABC-1D23', 'Fiat Argo 1.3', 2020), "
                + "(1, 'QWE-4R56', 'VW Gol 1.0', 2014), "
                + "(2, 'RTY-7U89', 'Honda Civic EXL', 2018), "
                + "(3, 'OPQ-5R61', 'Fiat Ducato', 2019)");

        st.execute("INSERT INTO peca (codigo, descricao, quantidade, minimo, preco) VALUES "
                + "('P-0001', 'Filtro de óleo Fram', 24, 10, 32.00), "
                + "('P-0002', 'Pastilha de freio dianteira', 4, 6, 109.90), "
                + "('P-0003', 'Amortecedor dianteiro', 2, 4, 349.90), "
                + "('P-0004', 'Vela de ignição NGK', 36, 16, 26.00), "
                + "('P-0005', 'Correia dentada', 0, 3, 149.90), "
                + "('P-0006', 'Óleo 5W30 sintético 1L', 32, 20, 49.90)");

        st.execute("INSERT INTO ordem_servico (veiculo_id, mecanico, problema, mao_de_obra, status, desconto, forma_pagamento, data_abertura) VALUES "
                + "(1, 'Anderson', 'Barulho na suspensão dianteira', 180.00, 'ABERTA', 0, NULL, CURDATE()), "
                + "(3, 'Paulo Ribeiro', 'Revisão dos 90 mil km', 135.00, 'PAGA', 0, 'Pix', CURDATE()), "
                + "(4, 'Anderson', 'Falha na partida', 90.00, 'ABERTA', 0, NULL, CURDATE())");

        st.execute("INSERT INTO item_os (os_id, peca_id, quantidade, valor_unitario) VALUES "
                + "(1037, 3, 2, 349.90), "
                + "(1038, 1, 1, 32.00), "
                + "(1038, 6, 4, 49.90), "
                + "(1039, 4, 4, 26.00)");
    }
}
