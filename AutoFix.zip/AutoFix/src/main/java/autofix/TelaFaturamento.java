package autofix;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** Aba de faturamento: escolhe uma OS aberta, aplica desconto e registra o pagamento. */
public class TelaFaturamento extends Tela {

    private JComboBox<OrdemServico> comboOs = new JComboBox<>();
    private DefaultTableModel modeloItens = Util.modelo("Código", "Peça", "Qtd", "Subtotal");
    private JTable tabelaItens = new JTable(modeloItens);

    private JLabel labelPecas = new JLabel("R$ 0,00");
    private JLabel labelMaoDeObra = new JLabel("R$ 0,00");
    private JLabel labelSubtotal = new JLabel("R$ 0,00");
    private JTextField campoDesconto = new JTextField("0", 10);
    private JComboBox<String> comboForma = new JComboBox<>(
            new String[]{"Dinheiro", "Pix", "Cartão de Débito", "Cartão de Crédito", "Boleto"});
    private JLabel labelTotal = new JLabel("R$ 0,00");

    private boolean carregando = false;   // evita reagir ao combo enquanto ele está sendo preenchido

    public TelaFaturamento() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topo.add(new JLabel("Ordem de serviço (em aberto):"));
        comboOs.setPreferredSize(new Dimension(420, 26));
        topo.add(comboOs);
        add(topo, BorderLayout.NORTH);

        add(new JScrollPane(tabelaItens), BorderLayout.CENTER);
        add(criarPagamento(), BorderLayout.SOUTH);

        comboOs.addActionListener(e -> mostrarOs());
        // recalcula o total enquanto digita o desconto
        campoDesconto.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                calcularTotal();
            }
        });

        atualizar();
    }

    private JPanel criarPagamento() {
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        Util.campo(formulario, "Total das peças:", labelPecas);
        Util.campo(formulario, "Mão de obra:", labelMaoDeObra);
        Util.campo(formulario, "Subtotal:", labelSubtotal);
        Util.campo(formulario, "Desconto (R$):", campoDesconto);
        Util.campo(formulario, "Forma de pagamento:", comboForma);
        labelTotal.setFont(labelTotal.getFont().deriveFont(Font.BOLD, 18f));
        Util.campo(formulario, "TOTAL A PAGAR:", labelTotal);

        JButton botaoConfirmar = new JButton("Confirmar pagamento");
        botaoConfirmar.addActionListener(e -> confirmar());

        JPanel alinhado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        alinhado.add(formulario);

        JPanel painel = new JPanel(new BorderLayout(0, 5));
        painel.setBorder(BorderFactory.createTitledBorder("Pagamento"));
        painel.add(alinhado, BorderLayout.CENTER);
        JPanel botao = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botao.add(botaoConfirmar);
        painel.add(botao, BorderLayout.SOUTH);
        return painel;
    }

    @Override
    public void atualizar() {
        try {
            carregando = true;
            comboOs.removeAllItems();
            List<OrdemServico> abertas = OrdemServicoDAO.listar(true);
            for (OrdemServico os : abertas) {
                comboOs.addItem(os);
            }
            carregando = false;
            campoDesconto.setText("0");
            mostrarOs();
        } catch (Exception e) {
            carregando = false;
            Util.erro(this, e);
        }
    }

    private void mostrarOs() {
        if (carregando) return;
        modeloItens.setRowCount(0);
        OrdemServico os = (OrdemServico) comboOs.getSelectedItem();
        if (os == null) {
            labelPecas.setText(Util.moeda(0));
            labelMaoDeObra.setText(Util.moeda(0));
            labelSubtotal.setText(Util.moeda(0));
            labelTotal.setText(Util.moeda(0));
            return;
        }
        try {
            for (ItemOS i : OrdemServicoDAO.listarItens(os.id)) {
                modeloItens.addRow(new Object[]{i.codigo, i.descricao, i.quantidade, Util.moeda(i.subtotal())});
            }
        } catch (Exception e) {
            Util.erro(this, e);
        }
        labelPecas.setText(Util.moeda(os.totalPecas));
        labelMaoDeObra.setText(Util.moeda(os.maoDeObra));
        labelSubtotal.setText(Util.moeda(os.subtotal()));
        calcularTotal();
    }

    private double lerDesconto() {
        String texto = campoDesconto.getText().trim();
        return texto.isEmpty() ? 0 : Util.numero(texto);
    }

    private void calcularTotal() {
        OrdemServico os = (OrdemServico) comboOs.getSelectedItem();
        if (os == null) return;
        try {
            labelTotal.setText(Util.moeda(os.subtotal() - lerDesconto()));
        } catch (Exception e) {
            labelTotal.setText("Desconto inválido");
        }
    }

    private void confirmar() {
        try {
            OrdemServico os = (OrdemServico) comboOs.getSelectedItem();
            if (os == null) {
                throw new IllegalArgumentException("Não há OS em aberto para faturar.");
            }
            double desconto = lerDesconto();
            if (desconto < 0 || desconto > os.subtotal()) {
                throw new IllegalArgumentException("O desconto deve ficar entre R$ 0,00 e o subtotal da OS.");
            }
            String forma = (String) comboForma.getSelectedItem();
            OrdemServicoDAO.pagar(os.id, desconto, forma);

            Util.aviso(this, "Pagamento confirmado!\nOS " + os.id + " - " + Util.moeda(os.subtotal() - desconto)
                    + "\nForma: " + forma);
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }
}
