package autofix;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Comandos SQL da tabela veiculo. */
public class VeiculoDAO {

    public static List<Veiculo> listar(String busca) throws SQLException {
        List<Veiculo> lista = new ArrayList<>();
        String sql = "SELECT v.*, c.nome AS cliente_nome FROM veiculo v "
                + "JOIN cliente c ON c.id = v.cliente_id "
                + "WHERE v.placa LIKE ? OR v.modelo LIKE ? OR c.nome LIKE ? ORDER BY v.placa";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            String texto = "%" + busca.trim() + "%";
            ps.setString(1, texto);
            ps.setString(2, texto);
            ps.setString(3, texto);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Veiculo v = new Veiculo();
                v.id = rs.getInt("id");
                v.clienteId = rs.getInt("cliente_id");
                v.clienteNome = rs.getString("cliente_nome");
                v.placa = rs.getString("placa");
                v.modelo = rs.getString("modelo");
                v.ano = rs.getInt("ano");
                lista.add(v);
            }
        }
        return lista;
    }

    public static void inserir(Veiculo v) throws SQLException {
        String sql = "INSERT INTO veiculo (cliente_id, placa, modelo, ano) VALUES (?, ?, ?, ?)";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, v.clienteId);
            ps.setString(2, v.placa);
            ps.setString(3, v.modelo);
            ps.setInt(4, v.ano);
            ps.executeUpdate();
        }
    }

    public static void atualizar(Veiculo v) throws SQLException {
        String sql = "UPDATE veiculo SET cliente_id = ?, placa = ?, modelo = ?, ano = ? WHERE id = ?";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, v.clienteId);
            ps.setString(2, v.placa);
            ps.setString(3, v.modelo);
            ps.setInt(4, v.ano);
            ps.setInt(5, v.id);
            ps.executeUpdate();
        }
    }

    public static void excluir(int id) throws SQLException {
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement("DELETE FROM veiculo WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
