package autofix;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Aba de clientes: formulário em cima, lista embaixo. Clique numa linha para editar. */
public class TelaClientes extends Tela {

    private JTextField campoNome = new JTextField(25);
    private JTextField campoCpf = new JTextField(25);
    private JTextField campoTelefone = new JTextField(25);
    private JTextField campoBusca = new JTextField(20);

    private DefaultTableModel modelo = Util.modelo("Nome", "CPF/CNPJ", "Telefone");
    private JTable tabela = new JTable(modelo);

    private List<Cliente> lista = new ArrayList<>();   // clientes que estão na tabela
    private Cliente selecionado = null;                // null = cadastrando um novo

    public TelaClientes() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ----- formulário -----
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        Util.campo(formulario, "Nome:", campoNome);
        Util.campo(formulario, "CPF/CNPJ:", campoCpf);
        Util.campo(formulario, "Telefone:", campoTelefone);

        JButton botaoSalvar = new JButton("Salvar");
        JButton botaoNovo = new JButton("Novo");
        JButton botaoExcluir = new JButton("Excluir");
        botaoSalvar.addActionListener(e -> salvar());
        botaoNovo.addActionListener(e -> limpar());
        botaoExcluir.addActionListener(e -> excluir());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botoes.add(botaoSalvar);
        botoes.add(botaoNovo);
        botoes.add(botaoExcluir);

        JPanel topo = new JPanel(new BorderLayout(0, 8));
        JPanel formularioAlinhado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formularioAlinhado.add(formulario);
        topo.add(formularioAlinhado, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);
        add(topo, BorderLayout.NORTH);

        // ----- busca + tabela -----
        JButton botaoBuscar = new JButton("Buscar");
        botaoBuscar.addActionListener(e -> atualizar());
        campoBusca.addActionListener(e -> atualizar());

        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        busca.add(new JLabel("Buscar:"));
        busca.add(campoBusca);
        busca.add(botaoBuscar);

        JPanel centro = new JPanel(new BorderLayout(0, 5));
        centro.add(busca, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        // quando clicar numa linha, preenche o formulário
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (!e.getValueIsAdjusting() && linha >= 0) {
                selecionado = lista.get(linha);
                campoNome.setText(selecionado.nome);
                campoCpf.setText(selecionado.cpf);
                campoTelefone.setText(selecionado.telefone);
            }
        });

        atualizar();
    }

    @Override
    public void atualizar() {
        try {
            lista = ClienteDAO.listar(campoBusca.getText());
            modelo.setRowCount(0);
            for (Cliente c : lista) {
                modelo.addRow(new Object[]{c.nome, c.cpf, c.telefone});
            }
            selecionado = null;
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void limpar() {
        tabela.clearSelection();
        selecionado = null;
        campoNome.setText("");
        campoCpf.setText("");
        campoTelefone.setText("");
    }

    private void salvar() {
        try {
            if (campoNome.getText().trim().length() < 3) {
                throw new IllegalArgumentException("Informe o nome do cliente (mínimo 3 letras).");
            }
            Cliente c = new Cliente();
            c.nome = campoNome.getText().trim();
            c.cpf = campoCpf.getText().trim().isEmpty() ? null : campoCpf.getText().trim();
            c.telefone = campoTelefone.getText().trim();

            if (selecionado == null) {
                ClienteDAO.inserir(c);
            } else {
                c.id = selecionado.id;
                ClienteDAO.atualizar(c);
            }
            limpar();
            atualizar();
            Util.aviso(this, "Cliente salvo com sucesso!");
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void excluir() {
        if (selecionado == null) {
            Util.aviso(this, "Clique em um cliente da lista para excluir.");
            return;
        }
        if (!Util.confirmar(this, "Excluir o cliente " + selecionado.nome + "?")) {
            return;
        }
        try {
            ClienteDAO.excluir(selecionado.id);
            limpar();
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }
}
