package autofix;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Comandos SQL da tabela peca (estoque). */
public class PecaDAO {

    public static List<Peca> listar(String busca) throws SQLException {
        List<Peca> lista = new ArrayList<>();
        String sql = "SELECT * FROM peca WHERE codigo LIKE ? OR descricao LIKE ? ORDER BY codigo";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            String texto = "%" + busca.trim() + "%";
            ps.setString(1, texto);
            ps.setString(2, texto);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Peca p = new Peca();
                p.id = rs.getInt("id");
                p.codigo = rs.getString("codigo");
                p.descricao = rs.getString("descricao");
                p.quantidade = rs.getInt("quantidade");
                p.minimo = rs.getInt("minimo");
                p.preco = rs.getDouble("preco");
                lista.add(p);
            }
        }
        return lista;
    }

    public static void inserir(Peca p) throws SQLException {
        String sql = "INSERT INTO peca (codigo, descricao, quantidade, minimo, preco) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.codigo);
            ps.setString(2, p.descricao);
            ps.setInt(3, p.quantidade);
            ps.setInt(4, p.minimo);
            ps.setDouble(5, p.preco);
            ps.executeUpdate();
        }
    }

    public static void atualizar(Peca p) throws SQLException {
        String sql = "UPDATE peca SET codigo = ?, descricao = ?, quantidade = ?, minimo = ?, preco = ? WHERE id = ?";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.codigo);
            ps.setString(2, p.descricao);
            ps.setInt(3, p.quantidade);
            ps.setInt(4, p.minimo);
            ps.setDouble(5, p.preco);
            ps.setInt(6, p.id);
            ps.executeUpdate();
        }
    }

    public static void excluir(int id) throws SQLException {
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement("DELETE FROM peca WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
