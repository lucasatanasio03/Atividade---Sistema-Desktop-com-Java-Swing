package autofix;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import java.sql.SQLException;
import java.util.Locale;

/** Pequenas funções que várias telas usam. */
public class Util {

    /** Cria o modelo de uma tabela (as células não podem ser editadas). */
    public static DefaultTableModel modelo(String... colunas) {
        return new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }
        };
    }

    /** Adiciona uma linha "rótulo + campo" em um formulário. */
    public static void campo(JPanel formulario, String rotulo, JComponent campo) {
        formulario.add(new JLabel(rotulo));
        formulario.add(campo);
    }

    /** Formata um valor como dinheiro: R$ 1.234,50 */
    public static String moeda(double valor) {
        return String.format(Locale.of("pt", "BR"), "R$ %,.2f", valor);
    }

    /** Converte texto em número. Aceita "1.234,50", "1234,50" e "1234.50". */
    public static double numero(String texto) {
        try {
            String t = texto.trim().replace("R$", "").replace(" ", "");
            if (t.contains(",")) {
                t = t.replace(".", "").replace(",", ".");
            }
            return Double.parseDouble(t);
        } catch (Exception e) {
            throw new IllegalArgumentException("Número inválido: \"" + texto + "\"");
        }
    }

    /** Converte texto em número inteiro. */
    public static int inteiro(String texto) {
        try {
            return Integer.parseInt(texto.trim());
        } catch (Exception e) {
            throw new IllegalArgumentException("Número inteiro inválido: \"" + texto + "\"");
        }
    }

    public static void aviso(Component tela, String mensagem) {
        JOptionPane.showMessageDialog(tela, mensagem, "AutoFix", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(Component tela, String pergunta) {
        return JOptionPane.showConfirmDialog(tela, pergunta, "Confirmação",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    /** Mostra uma mensagem de erro amigável. */
    public static void erro(Component tela, Exception e) {
        String mensagem = e.getMessage();
        if (e instanceof SQLException) {
            int codigo = ((SQLException) e).getErrorCode();
            if (codigo == 1062) {
                mensagem = "Já existe um cadastro com esse valor (CPF, placa ou código repetido).";
            } else if (codigo == 1451) {
                mensagem = "Não é possível excluir: existem outros cadastros ligados a este.";
            }
        }
        JOptionPane.showMessageDialog(tela, mensagem, "Atenção", JOptionPane.WARNING_MESSAGE);
    }
}
