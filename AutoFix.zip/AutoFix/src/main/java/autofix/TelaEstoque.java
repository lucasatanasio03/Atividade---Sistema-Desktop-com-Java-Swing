package autofix;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Aba de estoque de peças. Linha amarela = estoque baixo, vermelha = zerado. */
public class TelaEstoque extends Tela {

    private JTextField campoCodigo = new JTextField(25);
    private JTextField campoDescricao = new JTextField(25);
    private JTextField campoQuantidade = new JTextField(25);
    private JTextField campoMinimo = new JTextField(25);
    private JTextField campoPreco = new JTextField(25);
    private JTextField campoBusca = new JTextField(20);
    private JLabel labelAlerta = new JLabel(" ");

    private DefaultTableModel modelo = Util.modelo("Código", "Descrição", "Quantidade", "Mínimo", "Preço", "Situação");
    private JTable tabela = new JTable(modelo);

    private List<Peca> lista = new ArrayList<>();
    private Peca selecionada = null;

    public TelaEstoque() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        Util.campo(formulario, "Código:", campoCodigo);
        Util.campo(formulario, "Descrição:", campoDescricao);
        Util.campo(formulario, "Quantidade em estoque:", campoQuantidade);
        Util.campo(formulario, "Estoque mínimo:", campoMinimo);
        Util.campo(formulario, "Preço de venda (R$):", campoPreco);

        JButton botaoSalvar = new JButton("Salvar");
        JButton botaoNovo = new JButton("Novo");
        JButton botaoExcluir = new JButton("Excluir");
        botaoSalvar.addActionListener(e -> salvar());
        botaoNovo.addActionListener(e -> limpar());
        botaoExcluir.addActionListener(e -> excluir());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botoes.add(botaoSalvar);
        botoes.add(botaoNovo);
        botoes.add(botaoExcluir);

        JPanel topo = new JPanel(new BorderLayout(0, 8));
        JPanel formularioAlinhado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        formularioAlinhado.add(formulario);
        topo.add(formularioAlinhado, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);
        add(topo, BorderLayout.NORTH);

        JButton botaoBuscar = new JButton("Buscar");
        botaoBuscar.addActionListener(e -> atualizar());
        campoBusca.addActionListener(e -> atualizar());
        labelAlerta.setForeground(new Color(160, 90, 0));
        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        busca.add(new JLabel("Buscar:"));
        busca.add(campoBusca);
        busca.add(botaoBuscar);
        busca.add(labelAlerta);

        JPanel centro = new JPanel(new BorderLayout(0, 5));
        centro.add(busca, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        // pinta as linhas conforme a situação do estoque
        tabela.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean marcada,
                                                           boolean foco, int linha, int coluna) {
                Component c = super.getTableCellRendererComponent(t, valor, marcada, foco, linha, coluna);
                if (!marcada) {
                    String situacao = (String) modelo.getValueAt(linha, 5);
                    if (situacao.equals("ZERADO")) c.setBackground(new Color(255, 215, 215));
                    else if (situacao.equals("BAIXO")) c.setBackground(new Color(255, 245, 190));
                    else c.setBackground(Color.WHITE);
                }
                return c;
            }
        });

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (!e.getValueIsAdjusting() && linha >= 0) {
                selecionada = lista.get(linha);
                campoCodigo.setText(selecionada.codigo);
                campoDescricao.setText(selecionada.descricao);
                campoQuantidade.setText(String.valueOf(selecionada.quantidade));
                campoMinimo.setText(String.valueOf(selecionada.minimo));
                campoPreco.setText(String.format("%.2f", selecionada.preco).replace(".", ","));
            }
        });

        atualizar();
    }

    @Override
    public void atualizar() {
        try {
            lista = PecaDAO.listar(campoBusca.getText());
            modelo.setRowCount(0);
            int baixas = 0;
            for (Peca p : lista) {
                modelo.addRow(new Object[]{p.codigo, p.descricao, p.quantidade, p.minimo,
                        Util.moeda(p.preco), p.situacao()});
                if (!p.situacao().equals("OK")) baixas++;
            }
            labelAlerta.setText(baixas > 0 ? "Atenção: " + baixas + " peça(s) com estoque baixo ou zerado!" : " ");
            selecionada = null;
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void limpar() {
        tabela.clearSelection();
        selecionada = null;
        campoCodigo.setText("");
        campoDescricao.setText("");
        campoQuantidade.setText("");
        campoMinimo.setText("");
        campoPreco.setText("");
    }

    private void salvar() {
        try {
            if (campoCodigo.getText().trim().isEmpty() || campoDescricao.getText().trim().isEmpty()) {
                throw new IllegalArgumentException("Informe o código e a descrição da peça.");
            }
            Peca p = new Peca();
            p.codigo = campoCodigo.getText().trim().toUpperCase();
            p.descricao = campoDescricao.getText().trim();
            p.quantidade = Util.inteiro(campoQuantidade.getText());
            p.minimo = Util.inteiro(campoMinimo.getText());
            p.preco = Util.numero(campoPreco.getText());
            if (p.quantidade < 0 || p.minimo < 0 || p.preco <= 0) {
                throw new IllegalArgumentException("Quantidade e mínimo não podem ser negativos, e o preço deve ser maior que zero.");
            }

            if (selecionada == null) {
                PecaDAO.inserir(p);
            } else {
                p.id = selecionada.id;
                PecaDAO.atualizar(p);
            }
            limpar();
            atualizar();
            Util.aviso(this, "Peça salva com sucesso!");
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void excluir() {
        if (selecionada == null) {
            Util.aviso(this, "Clique em uma peça da lista para excluir.");
            return;
        }
        if (!Util.confirmar(this, "Excluir a peça " + selecionada.codigo + "?")) {
            return;
        }
        try {
            PecaDAO.excluir(selecionada.id);
            limpar();
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }
}
