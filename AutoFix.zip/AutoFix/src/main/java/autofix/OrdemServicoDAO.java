package autofix;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Comandos SQL das ordens de serviço, das peças da OS e do pagamento. */
public class OrdemServicoDAO {

    // ---------- ordens de serviço ----------

    public static List<OrdemServico> listar(boolean somenteAbertas) throws SQLException {
        List<OrdemServico> lista = new ArrayList<>();
        String sql = "SELECT o.*, v.placa, v.modelo, c.nome AS cliente_nome, "
                + "(SELECT COALESCE(SUM(i.quantidade * i.valor_unitario), 0) FROM item_os i WHERE i.os_id = o.id) AS total_pecas "
                + "FROM ordem_servico o "
                + "JOIN veiculo v ON v.id = o.veiculo_id "
                + "JOIN cliente c ON c.id = v.cliente_id "
                + (somenteAbertas ? "WHERE o.status = 'ABERTA' " : "")
                + "ORDER BY o.id DESC";
        try (Connection c = Banco.conectar(); Statement st = c.createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                OrdemServico os = new OrdemServico();
                os.id = rs.getInt("id");
                os.veiculoId = rs.getInt("veiculo_id");
                os.placa = rs.getString("placa");
                os.modelo = rs.getString("modelo");
                os.clienteNome = rs.getString("cliente_nome");
                os.mecanico = rs.getString("mecanico");
                os.problema = rs.getString("problema");
                os.maoDeObra = rs.getDouble("mao_de_obra");
                os.totalPecas = rs.getDouble("total_pecas");
                os.desconto = rs.getDouble("desconto");
                os.status = rs.getString("status");
                os.formaPagamento = rs.getString("forma_pagamento");
                lista.add(os);
            }
        }
        return lista;
    }

    public static void inserir(OrdemServico os) throws SQLException {
        String sql = "INSERT INTO ordem_servico (veiculo_id, mecanico, problema, mao_de_obra, data_abertura) "
                + "VALUES (?, ?, ?, ?, CURDATE())";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, os.veiculoId);
            ps.setString(2, os.mecanico);
            ps.setString(3, os.problema);
            ps.setDouble(4, os.maoDeObra);
            ps.executeUpdate();
        }
    }

    public static void atualizar(OrdemServico os) throws SQLException {
        String sql = "UPDATE ordem_servico SET veiculo_id = ?, mecanico = ?, problema = ?, mao_de_obra = ? "
                + "WHERE id = ? AND status = 'ABERTA'";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, os.veiculoId);
            ps.setString(2, os.mecanico);
            ps.setString(3, os.problema);
            ps.setDouble(4, os.maoDeObra);
            ps.setInt(5, os.id);
            if (ps.executeUpdate() == 0) {
                throw new SQLException("Esta OS já foi paga e não pode ser alterada.");
            }
        }
    }

    /** Exclui a OS e devolve as peças dela para o estoque. */
    public static void excluir(int osId) throws SQLException {
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);   // as duas operações abaixo acontecem juntas ou nenhuma acontece
            try {
                verificarAberta(c, osId);
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE peca p JOIN item_os i ON i.peca_id = p.id "
                        + "SET p.quantidade = p.quantidade + i.quantidade WHERE i.os_id = ?")) {
                    ps.setInt(1, osId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM ordem_servico WHERE id = ?")) {
                    ps.setInt(1, osId);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    // ---------- peças da OS ----------

    public static List<ItemOS> listarItens(int osId) throws SQLException {
        List<ItemOS> lista = new ArrayList<>();
        String sql = "SELECT i.*, p.codigo, p.descricao FROM item_os i "
                + "JOIN peca p ON p.id = i.peca_id WHERE i.os_id = ? ORDER BY i.id";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, osId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ItemOS item = new ItemOS();
                item.id = rs.getInt("id");
                item.codigo = rs.getString("codigo");
                item.descricao = rs.getString("descricao");
                item.quantidade = rs.getInt("quantidade");
                item.valorUnitario = rs.getDouble("valor_unitario");
                lista.add(item);
            }
        }
        return lista;
    }

    /** Coloca a peça na OS e já tira do estoque. Se não tiver estoque, dá erro. */
    public static void adicionarItem(int osId, int pecaId, int quantidade) throws SQLException {
        if (quantidade <= 0) {
            throw new SQLException("A quantidade deve ser maior que zero.");
        }
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try {
                verificarAberta(c, osId);

                // tira do estoque (só funciona se tiver quantidade suficiente)
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE peca SET quantidade = quantidade - ? WHERE id = ? AND quantidade >= ?")) {
                    ps.setInt(1, quantidade);
                    ps.setInt(2, pecaId);
                    ps.setInt(3, quantidade);
                    if (ps.executeUpdate() == 0) {
                        throw new SQLException("Estoque insuficiente para esta peça.");
                    }
                }
                // grava na OS com o preço de agora
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO item_os (os_id, peca_id, quantidade, valor_unitario) "
                        + "SELECT ?, id, ?, preco FROM peca WHERE id = ?")) {
                    ps.setInt(1, osId);
                    ps.setInt(2, quantidade);
                    ps.setInt(3, pecaId);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** Tira a peça da OS e devolve para o estoque. */
    public static void removerItem(int osId, int itemId) throws SQLException {
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try {
                verificarAberta(c, osId);
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE peca p JOIN item_os i ON i.peca_id = p.id "
                        + "SET p.quantidade = p.quantidade + i.quantidade WHERE i.id = ?")) {
                    ps.setInt(1, itemId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM item_os WHERE id = ?")) {
                    ps.setInt(1, itemId);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    // ---------- pagamento ----------

    /** Registra o pagamento e fecha a OS. */
    public static void pagar(int osId, double desconto, String forma) throws SQLException {
        String sql = "UPDATE ordem_servico SET status = 'PAGA', desconto = ?, forma_pagamento = ? "
                + "WHERE id = ? AND status = 'ABERTA'";
        try (Connection c = Banco.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setDouble(1, desconto);
            ps.setString(2, forma);
            ps.setInt(3, osId);
            if (ps.executeUpdate() == 0) {
                throw new SQLException("Esta OS já foi paga.");
            }
        }
    }

    /** Dá erro se a OS já estiver paga. */
    private static void verificarAberta(Connection c, int osId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT status FROM ordem_servico WHERE id = ?")) {
            ps.setInt(1, osId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new SQLException("OS não encontrada.");
            }
            if (!rs.getString("status").equals("ABERTA")) {
                throw new SQLException("Esta OS já foi paga e não pode ser alterada.");
            }
        }
    }
}
