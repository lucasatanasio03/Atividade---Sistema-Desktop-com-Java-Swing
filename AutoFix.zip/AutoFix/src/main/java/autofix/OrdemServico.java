package autofix;

/** Uma ordem de serviço (OS). */
public class OrdemServico {
    public int id;
    public int veiculoId;
    public String placa;
    public String modelo;
    public String clienteNome;
    public String mecanico;
    public String problema;
    public double maoDeObra;
    public double totalPecas;
    public double desconto;
    public String status;          // "ABERTA" ou "PAGA"
    public String formaPagamento;

    /** Peças + mão de obra (sem desconto). */
    public double subtotal() {
        return totalPecas + maoDeObra;
    }

    /** Valor final, já com desconto. */
    public double total() {
        return subtotal() - desconto;
    }

    @Override
    public String toString() {
        return "OS " + id + " - " + clienteNome + " - " + placa;
    }
}
