package autofix;

/** Um veículo (pertence a um cliente). */
public class Veiculo {
    public int id;
    public int clienteId;
    public String clienteNome;
    public String placa;
    public String modelo;
    public int ano;

    @Override
    public String toString() {
        return placa + " - " + modelo + " (" + clienteNome + ")";
    }
}
