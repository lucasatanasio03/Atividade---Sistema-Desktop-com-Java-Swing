package autofix;

/** Um cliente da oficina. */
public class Cliente {
    public int id;
    public String nome;
    public String cpf;
    public String telefone;

    @Override
    public String toString() {   // é o texto mostrado nas caixas de seleção
        return nome;
    }
}
