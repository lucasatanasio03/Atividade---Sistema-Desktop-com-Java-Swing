package autofix;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Aba de ordens de serviço.
 * Em cima: dados da OS. No meio: lista de OS. Embaixo: peças da OS selecionada.
 */
public class TelaOrdens extends Tela {

    // dados da OS
    private JComboBox<Veiculo> comboVeiculo = new JComboBox<>();
    private JTextField campoMecanico = new JTextField(25);
    private JTextField campoProblema = new JTextField(25);
    private JTextField campoMaoDeObra = new JTextField(25);

    private DefaultTableModel modeloOs = Util.modelo("Nº OS", "Cliente", "Veículo", "Mecânico", "Status", "Total");
    private JTable tabelaOs = new JTable(modeloOs);
    private List<OrdemServico> listaOs = new ArrayList<>();
    private OrdemServico selecionada = null;

    // peças da OS
    private JComboBox<Peca> comboPeca = new JComboBox<>();
    private JTextField campoQuantidade = new JTextField("1", 4);
    private DefaultTableModel modeloItens = Util.modelo("Código", "Peça", "Qtd", "Valor unit.", "Subtotal");
    private JTable tabelaItens = new JTable(modeloItens);
    private List<ItemOS> listaItens = new ArrayList<>();
    private JLabel labelTotal = new JLabel("Selecione uma OS na lista");

    public TelaOrdens() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        add(criarTopo(), BorderLayout.NORTH);
        add(new JScrollPane(tabelaOs), BorderLayout.CENTER);
        add(criarPainelPecas(), BorderLayout.SOUTH);

        tabelaOs.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabelaOs.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabelaOs.getSelectedRow();
            if (!e.getValueIsAdjusting() && linha >= 0) {
                selecionada = listaOs.get(linha);
                preencherFormulario();
                carregarItens();
            }
        });

        atualizar();
    }

    private JPanel criarTopo() {
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        Util.campo(formulario, "Veículo:", comboVeiculo);
        Util.campo(formulario, "Mecânico:", campoMecanico);
        Util.campo(formulario, "Problema relatado:", campoProblema);
        Util.campo(formulario, "Mão de obra (R$):", campoMaoDeObra);

        JButton botaoSalvar = new JButton("Salvar OS");
        JButton botaoNovo = new JButton("Nova OS");
        JButton botaoExcluir = new JButton("Excluir OS");
        botaoSalvar.addActionListener(e -> salvar());
        botaoNovo.addActionListener(e -> limpar());
        botaoExcluir.addActionListener(e -> excluir());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botoes.add(botaoSalvar);
        botoes.add(botaoNovo);
        botoes.add(botaoExcluir);

        JPanel alinhado = new JPanel(new FlowLayout(FlowLayout.LEFT));
        alinhado.add(formulario);

        JPanel topo = new JPanel(new BorderLayout(0, 5));
        topo.add(alinhado, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);
        return topo;
    }

    private JPanel criarPainelPecas() {
        JButton botaoAdicionar = new JButton("Adicionar peça");
        JButton botaoRemover = new JButton("Remover peça selecionada");
        botaoAdicionar.addActionListener(e -> adicionarPeca());
        botaoRemover.addActionListener(e -> removerPeca());

        JPanel linha = new JPanel(new FlowLayout(FlowLayout.LEFT));
        linha.add(new JLabel("Peça:"));
        linha.add(comboPeca);
        linha.add(new JLabel("Qtd:"));
        linha.add(campoQuantidade);
        linha.add(botaoAdicionar);
        linha.add(botaoRemover);

        tabelaItens.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane rolagem = new JScrollPane(tabelaItens);
        rolagem.setPreferredSize(new Dimension(100, 120));

        labelTotal.setFont(labelTotal.getFont().deriveFont(Font.BOLD, 14f));

        JPanel painel = new JPanel(new BorderLayout(0, 5));
        painel.setBorder(BorderFactory.createTitledBorder("Peças da OS selecionada"));
        painel.add(linha, BorderLayout.NORTH);
        painel.add(rolagem, BorderLayout.CENTER);
        painel.add(labelTotal, BorderLayout.SOUTH);
        return painel;
    }

    @Override
    public void atualizar() {
        try {
            int idAnterior = selecionada == null ? 0 : selecionada.id;

            comboVeiculo.removeAllItems();
            for (Veiculo v : VeiculoDAO.listar("")) {
                comboVeiculo.addItem(v);
            }
            comboPeca.removeAllItems();
            for (Peca p : PecaDAO.listar("")) {
                comboPeca.addItem(p);
            }

            listaOs = OrdemServicoDAO.listar(false);
            modeloOs.setRowCount(0);
            for (OrdemServico os : listaOs) {
                String status = os.status.equals("PAGA") ? "Paga" : "Aberta";
                modeloOs.addRow(new Object[]{os.id, os.clienteNome, os.placa + " - " + os.modelo,
                        os.mecanico, status, Util.moeda(os.total())});
            }
            selecionada = null;

            // volta a selecionar a OS que estava aberta na tela
            for (int i = 0; i < listaOs.size(); i++) {
                if (listaOs.get(i).id == idAnterior) {
                    tabelaOs.setRowSelectionInterval(i, i);
                }
            }
            if (selecionada == null) {
                limparItens();
            }
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void preencherFormulario() {
        for (int i = 0; i < comboVeiculo.getItemCount(); i++) {
            if (comboVeiculo.getItemAt(i).id == selecionada.veiculoId) {
                comboVeiculo.setSelectedIndex(i);
            }
        }
        campoMecanico.setText(selecionada.mecanico);
        campoProblema.setText(selecionada.problema);
        campoMaoDeObra.setText(String.format("%.2f", selecionada.maoDeObra).replace(".", ","));
    }

    private void limpar() {
        tabelaOs.clearSelection();
        selecionada = null;
        campoMecanico.setText("");
        campoProblema.setText("");
        campoMaoDeObra.setText("");
        limparItens();
    }

    private void limparItens() {
        modeloItens.setRowCount(0);
        listaItens.clear();
        labelTotal.setText("Selecione uma OS na lista");
    }

    private void carregarItens() {
        try {
            listaItens = OrdemServicoDAO.listarItens(selecionada.id);
            modeloItens.setRowCount(0);
            for (ItemOS i : listaItens) {
                modeloItens.addRow(new Object[]{i.codigo, i.descricao, i.quantidade,
                        Util.moeda(i.valorUnitario), Util.moeda(i.subtotal())});
            }
            labelTotal.setText("Peças: " + Util.moeda(selecionada.totalPecas)
                    + "   |   Mão de obra: " + Util.moeda(selecionada.maoDeObra)
                    + "   |   TOTAL: " + Util.moeda(selecionada.subtotal())
                    + (selecionada.status.equals("PAGA") ? "   (OS paga)" : ""));
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void salvar() {
        try {
            Veiculo veiculo = (Veiculo) comboVeiculo.getSelectedItem();
            if (veiculo == null) {
                throw new IllegalArgumentException("Cadastre um veículo antes de abrir uma OS.");
            }
            OrdemServico os = new OrdemServico();
            os.veiculoId = veiculo.id;
            os.mecanico = campoMecanico.getText().trim();
            os.problema = campoProblema.getText().trim();
            os.maoDeObra = campoMaoDeObra.getText().trim().isEmpty() ? 0 : Util.numero(campoMaoDeObra.getText());
            if (os.maoDeObra < 0) {
                throw new IllegalArgumentException("A mão de obra não pode ser negativa.");
            }

            if (selecionada == null) {
                OrdemServicoDAO.inserir(os);
            } else {
                os.id = selecionada.id;
                OrdemServicoDAO.atualizar(os);
            }
            atualizar();
            Util.aviso(this, "OS salva com sucesso!");
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void excluir() {
        if (selecionada == null) {
            Util.aviso(this, "Clique em uma OS da lista para excluir.");
            return;
        }
        if (!Util.confirmar(this, "Excluir a OS " + selecionada.id + "? As peças voltam para o estoque.")) {
            return;
        }
        try {
            OrdemServicoDAO.excluir(selecionada.id);
            limpar();
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void adicionarPeca() {
        try {
            if (selecionada == null) {
                throw new IllegalArgumentException("Clique em uma OS da lista primeiro.");
            }
            Peca peca = (Peca) comboPeca.getSelectedItem();
            if (peca == null) {
                throw new IllegalArgumentException("Cadastre peças no estoque primeiro.");
            }
            OrdemServicoDAO.adicionarItem(selecionada.id, peca.id, Util.inteiro(campoQuantidade.getText()));
            campoQuantidade.setText("1");
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }

    private void removerPeca() {
        try {
            int linha = tabelaItens.getSelectedRow();
            if (selecionada == null || linha < 0) {
                throw new IllegalArgumentException("Clique na peça que deseja remover.");
            }
            OrdemServicoDAO.removerItem(selecionada.id, listaItens.get(linha).id);
            atualizar();
        } catch (Exception e) {
            Util.erro(this, e);
        }
    }
}
