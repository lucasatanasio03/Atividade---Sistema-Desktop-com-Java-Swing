package autofix;

/** Uma peça do estoque. */
public class Peca {
    public int id;
    public String codigo;
    public String descricao;
    public int quantidade;
    public int minimo;
    public double preco;

    public String situacao() {
        if (quantidade == 0) return "ZERADO";
        if (quantidade <= minimo) return "BAIXO";
        return "OK";
    }

    @Override
    public String toString() {
        return codigo + " - " + descricao + " (estoque: " + quantidade + ")";
    }
}
