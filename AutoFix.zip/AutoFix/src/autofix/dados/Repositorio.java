package autofix.dados;

import autofix.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * "Banco de dados" do sistema: guarda tudo em listas na memória.
 * Os dados são perdidos ao fechar o programa (numa próxima etapa pode ser
 * trocado por um banco de verdade usando JDBC).
 * Usa o padrão Singleton: só existe uma instância, acessada por getInstance().
 */
public class Repositorio {

    private static final Repositorio INSTANCIA = new Repositorio();

    public static Repositorio getInstance() {
        return INSTANCIA;
    }

    private final List<Cliente> clientes = new ArrayList<>();
    private final List<Mecanico> mecanicos = new ArrayList<>();
    private final List<Peca> pecas = new ArrayList<>();
    private final List<OrdemServico> ordens = new ArrayList<>();
    private final List<Faturamento> faturamentos = new ArrayList<>();

    private int proxIdCliente = 1;
    private int proxIdVeiculo = 1;
    private int proxIdMecanico = 1;
    private int proxIdPeca = 1;
    private int proxNumeroOS = 1037;
    private int proxIdFaturamento = 1;

    private Repositorio() {
        carregarDadosExemplo();
    }

    // ---------------- consultas ----------------

    public List<Cliente> getClientes() { return Collections.unmodifiableList(clientes); }
    public List<Mecanico> getMecanicos() { return Collections.unmodifiableList(mecanicos); }
    public List<Peca> getPecas() { return Collections.unmodifiableList(pecas); }
    public List<OrdemServico> getOrdens() { return Collections.unmodifiableList(ordens); }
    public List<Faturamento> getFaturamentos() { return Collections.unmodifiableList(faturamentos); }

    public Cliente buscarClientePorDocumento(String documentoSoDigitos) {
        for (Cliente c : clientes) {
            if (soDigitos(c.getCpfCnpj()).equals(documentoSoDigitos)) {
                return c;
            }
        }
        return null;
    }

    public Veiculo buscarVeiculoPorPlaca(String placa) {
        String procurada = normalizarPlaca(placa);
        for (Cliente c : clientes) {
            for (Veiculo v : c.getVeiculos()) {
                if (normalizarPlaca(v.getPlaca()).equals(procurada)) {
                    return v;
                }
            }
        }
        return null;
    }

    public Peca buscarPecaPorCodigo(String codigo) {
        for (Peca p : pecas) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return p;
            }
        }
        return null;
    }

    private static String soDigitos(String texto) {
        return texto == null ? "" : texto.replaceAll("[^0-9]", "");
    }

    private static String normalizarPlaca(String placa) {
        return placa == null ? "" : placa.replace("-", "").trim().toUpperCase();
    }

    // ---------------- clientes e veículos ----------------

    public void adicionarCliente(Cliente cliente) {
        cliente.setId(proxIdCliente++);
        clientes.add(cliente);
    }

    public void removerCliente(Cliente cliente) {
        for (OrdemServico os : ordens) {
            if (os.getCliente() == cliente) {
                throw new IllegalStateException("O cliente possui ordens de serviço e não pode ser excluído.");
            }
        }
        clientes.remove(cliente);
    }

    public void adicionarVeiculo(Cliente cliente, Veiculo veiculo) {
        veiculo.setId(proxIdVeiculo++);
        cliente.adicionarVeiculo(veiculo);
    }

    public void removerVeiculo(Veiculo veiculo) {
        for (OrdemServico os : ordens) {
            if (os.getVeiculo() == veiculo) {
                throw new IllegalStateException("O veículo possui ordens de serviço e não pode ser removido.");
            }
        }
        veiculo.getCliente().removerVeiculo(veiculo);
    }

    // ---------------- mecânicos ----------------

    public Mecanico adicionarMecanico(String nome) {
        Mecanico m = new Mecanico(nome);
        m.setId(proxIdMecanico++);
        mecanicos.add(m);
        return m;
    }

    // ---------------- peças ----------------

    public void adicionarPeca(Peca peca) {
        peca.setId(proxIdPeca++);
        pecas.add(peca);
    }

    public void removerPeca(Peca peca) {
        for (OrdemServico os : ordens) {
            if (os.quantidadeDaPeca(peca) > 0) {
                throw new IllegalStateException("A peça está em uma ordem de serviço e não pode ser excluída.");
            }
        }
        pecas.remove(peca);
    }

    // ---------------- ordens de serviço ----------------

    public OrdemServico novaOS(Veiculo veiculo, Mecanico mecanico, int kmEntrada, String problema) {
        OrdemServico os = new OrdemServico(proxNumeroOS++, veiculo, mecanico, kmEntrada, problema);
        ordens.add(os);
        return os;
    }

    public void removerOS(OrdemServico os) {
        if (os.isFaturada()) {
            throw new IllegalStateException("Uma OS já faturada não pode ser excluída.");
        }
        ordens.remove(os);
    }

    /** Fecha a conta da OS e guarda o faturamento. A regra de negócio está em OrdemServico.faturar(). */
    public Faturamento faturar(OrdemServico os, double desconto, FormaPagamento forma,
                               int parcelas, double valorRecebido) {
        Faturamento f = os.faturar(desconto, forma, parcelas, valorRecebido);
        f.setId(proxIdFaturamento++);
        faturamentos.add(f);
        return f;
    }

    // ---------------- dados de exemplo ----------------

    private void carregarDadosExemplo() {
        Mecanico anderson = adicionarMecanico("Anderson");
        Mecanico paulo = adicionarMecanico("Paulo Ribeiro");

        Cliente carlos = novoCliente("Carlos Eduardo Silva", "123.456.789-00", "(47) 99123-4567",
                "carlos.silva@email.com", "Rua das Palmeiras, 250 - Centro - Joinville/SC");
        Veiculo argo = novoVeiculo(carlos, "ABC-1D23", "Fiat", "Argo 1.3", 2020, "Prata", 48200);
        novoVeiculo(carlos, "QWE-4R56", "VW", "Gol 1.0", 2014, "Branco", 132900);
        novoVeiculo(carlos, "RTY-7U89", "Honda", "Civic EXL", 2018, "Preto", 87450);

        Cliente marina = novoCliente("Marina Souza Lima", "987.654.321-00", "(47) 99876-1122",
                "marina.lima@email.com", "Av. Beira Rio, 1020 - Anita Garibaldi - Joinville/SC");
        Veiculo onix = novoVeiculo(marina, "KLM-2N34", "Chevrolet", "Onix 1.0", 2019, "Vermelho", 61300);

        Cliente roberto = novoCliente("Roberto Almeida", "456.789.123-00", "(47) 98811-3344",
                "roberto.almeida@email.com", "Rua XV de Novembro, 88 - Centro - Joinville/SC");
        Veiculo hb20 = novoVeiculo(roberto, "HJK-9P87", "Hyundai", "HB20 1.6", 2017, "Cinza", 99800);
        novoVeiculo(roberto, "BRA-2E19", "Toyota", "Corolla XEi", 2021, "Branco", 35400);

        Cliente transportes = novoCliente("Transportes Norte Ltda", "12.345.678/0001-90", "(47) 3422-5566",
                "contato@transportesnorte.com.br", "Rod. BR-101, km 40 - Joinville/SC");
        Veiculo fiorino = novoVeiculo(transportes, "OPQ-5R61", "Fiat", "Fiorino 1.4", 2016, "Branco", 188000);

        Cliente fernanda = novoCliente("Fernanda Costa", "321.654.987-00", "(47) 99700-8899",
                "fernanda.costa@email.com", "Rua Blumenau, 400 - Atiradores - Joinville/SC");
        Veiculo polo = novoVeiculo(fernanda, "STU-8V20", "VW", "Polo 1.0", 2022, "Azul", 22900);

        Cliente joao = novoCliente("João Pedro Martins", "741.852.963-00", "(47) 99655-4433",
                "joao.martins@email.com", "Rua Itajaí, 15 - Bucarein - Joinville/SC");
        Veiculo kwid = novoVeiculo(joao, "XYZ-3A45", "Renault", "Kwid", 2021, "Laranja", 30100);

        Peca filtroOleo = novaPeca("P-0001", "Filtro de óleo Fram PH5949", "Filtros", 25, 10, 18.50, 32.00);
        Peca pastilha = novaPeca("P-0002", "Pastilha de freio dianteira Cobreq", "Freios", 4, 6, 62.00, 109.90);
        Peca amortecedor = novaPeca("P-0003", "Amortecedor dianteiro Monroe", "Suspensão", 2, 4, 210.00, 349.90);
        Peca vela = novaPeca("P-0004", "Vela de ignição NGK", "Ignição", 40, 16, 14.00, 26.00);
        Peca correia = novaPeca("P-0005", "Correia dentada Gates", "Motor", 0, 3, 85.00, 149.90);
        Peca oleo = novaPeca("P-0006", "Óleo 5W30 sintético 1L", "Lubrificantes", 36, 20, 29.00, 49.90);
        novaPeca("P-0007", "Disco de freio ventilado", "Freios", 8, 4, 118.00, 199.00);
        novaPeca("P-0008", "Bateria 60Ah", "Elétrica", 3, 3, 340.00, 529.00);
        novaPeca("P-0009", "Filtro de ar Mann", "Filtros", 15, 8, 22.00, 39.90);
        novaPeca("P-0010", "Terminal de direção", "Direção", 5, 4, 45.00, 79.90);

        // OS 1037 - aberta
        OrdemServico os1037 = novaOS(kwid, paulo, 30100, "Revisão dos 30 mil km");
        os1037.setDataAbertura(LocalDate.now().minusDays(1));

        // OS 1038 - concluída e já faturada (aparece em "somente leitura")
        OrdemServico os1038 = novaOS(polo, anderson, 22900, "Troca de óleo e filtro");
        os1038.setDataAbertura(LocalDate.now().minusDays(6));
        os1038.adicionarPeca(filtroOleo, 1);
        os1038.adicionarPeca(oleo, 4);
        os1038.adicionarServico(new ServicoMaoDeObra("Troca de óleo e filtro", 0.5, 90.00));
        faturar(os1038, 0, FormaPagamento.PIX, 1, 0);

        // OS 1039 - concluída, pronta para ser faturada
        OrdemServico os1039 = novaOS(fiorino, paulo, 188000, "Motor falhando em marcha lenta");
        os1039.setDataAbertura(LocalDate.now().minusDays(3));
        os1039.adicionarPeca(vela, 4);
        os1039.adicionarServico(new ServicoMaoDeObra("Troca das velas e limpeza dos bicos", 1.5, 90.00));
        os1039.setStatus(StatusOS.CONCLUIDA);

        // OS 1040 - aberta
        OrdemServico os1040 = novaOS(hb20, anderson, 99800, "Pastilhas de freio fazendo ruído");
        os1040.setDataAbertura(LocalDate.now().minusDays(2));

        // OS 1041 - aguardando peças (a correia está com o estoque zerado)
        OrdemServico os1041 = novaOS(onix, paulo, 61300, "Troca da correia dentada");
        os1041.setDataAbertura(LocalDate.now().minusDays(2));
        os1041.adicionarPeca(correia, 1);
        os1041.adicionarServico(new ServicoMaoDeObra("Troca da correia dentada", 3.0, 90.00));
        os1041.setStatus(StatusOS.AGUARDANDO_PECAS);

        // OS 1042 - em andamento (a mesma do protótipo do Figma)
        OrdemServico os1042 = novaOS(argo, anderson, 48200, "Barulho na suspensão dianteira");
        os1042.setDataAbertura(LocalDate.now().minusDays(1));
        os1042.adicionarPeca(amortecedor, 2);
        os1042.adicionarPeca(filtroOleo, 1);
        os1042.adicionarPeca(oleo, 4);
        os1042.adicionarServico(new ServicoMaoDeObra("Troca de amortecedores", 2.0, 90.00));
        os1042.adicionarServico(new ServicoMaoDeObra("Troca de óleo e filtro", 0.5, 90.00));
        os1042.setStatus(StatusOS.EM_ANDAMENTO);
    }

    private Cliente novoCliente(String nome, String doc, String tel, String email, String end) {
        Cliente c = new Cliente(nome, doc, tel, email, end);
        adicionarCliente(c);
        return c;
    }

    private Veiculo novoVeiculo(Cliente c, String placa, String marca, String modelo, int ano, String cor, int km) {
        Veiculo v = new Veiculo(placa, marca, modelo, ano, cor, km);
        adicionarVeiculo(c, v);
        return v;
    }

    private Peca novaPeca(String cod, String desc, String cat, int qtd, int min, double custo, double venda) {
        Peca p = new Peca(cod, desc, cat, qtd, min, custo, venda);
        adicionarPeca(p);
        return p;
    }
}
