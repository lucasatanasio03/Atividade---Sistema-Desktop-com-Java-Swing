package autofix.view;

import autofix.dados.Repositorio;
import autofix.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Aba 4: fechamento de conta / faturamento (resumo da OS, forma de pagamento e baixa automática). */
public class PainelFaturamento extends JPanel implements Atualizavel {

    private final Repositorio repo = Repositorio.getInstance();
    private final JanelaPrincipal janela;

    private final JComboBox<OrdemServico> cmbOS = new JComboBox<>();
    private final JLabel lblCliente = new JLabel("-");
    private final JLabel lblVeiculo = new JLabel("-");
    private final JLabel lblMecanico = new JLabel("-");
    private final ModeloTabela modeloPecas = new ModeloTabela("Peça", "Qtd.", "Unit. (R$)", "Subtotal (R$)");
    private final ModeloTabela modeloServicos = new ModeloTabela("Serviço", "Horas", "Valor/h (R$)", "Subtotal (R$)");
    private final JTable tabPecas = Util.criarTabela(modeloPecas);
    private final JTable tabServicos = Util.criarTabela(modeloServicos);
    private final JLabel lblTotalPecas = new JLabel("R$ 0,00");
    private final JLabel lblTotalServicos = new JLabel("R$ 0,00");
    private final JTextField txtDesconto = new JTextField("0,00", 8);
    private final JLabel lblTotal = new JLabel("R$ 0,00");

    private final JRadioButton[] radios = new JRadioButton[FormaPagamento.values().length];
    private final JComboBox<String> cmbParcelas = new JComboBox<>();
    private final JTextField txtRecebido = new JTextField(10);
    private final JLabel lblTroco = new JLabel("R$ 0,00");
    private final JButton btnConfirmar = new JButton("Confirmar Pagamento");
    private final JButton btnLimpar = new JButton("Limpar");

    private boolean carregando = false;

    public PainelFaturamento(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(12, 0));
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        add(montarResumo(), BorderLayout.CENTER);
        add(montarPagamento(), BorderLayout.EAST);
        atualizar();
    }

    // ====================== montagem da tela ======================

    private JPanel montarResumo() {
        JPanel painel = Util.painelComTitulo("Resumo da OS", new BorderLayout(0, 8));

        cmbOS.addActionListener(e -> {
            if (!carregando) {
                carregarOS();
            }
        });
        JPanel escolha = new JPanel(new BorderLayout(6, 0));
        escolha.add(new JLabel("OS a faturar:"), BorderLayout.WEST);
        escolha.add(cmbOS, BorderLayout.CENTER);

        JPanel dados = new JPanel(new GridLayout(0, 2, 6, 3));
        adicionar(dados, "Cliente:", lblCliente);
        adicionar(dados, "Veículo:", lblVeiculo);
        adicionar(dados, "Mecânico:", lblMecanico);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.add(escolha, BorderLayout.NORTH);
        norte.add(dados, BorderLayout.CENTER);

        Util.larguras(tabPecas, 230, 40, 90, 100);
        Util.alinharDireita(tabPecas, 1, 2, 3);
        Util.larguras(tabServicos, 230, 40, 90, 100);
        Util.alinharDireita(tabServicos, 1, 2, 3);
        JPanel pecas = Util.painelComTitulo("Peças", new BorderLayout());
        pecas.add(new JScrollPane(tabPecas), BorderLayout.CENTER);
        JPanel servicos = Util.painelComTitulo("Mão de obra", new BorderLayout());
        servicos.add(new JScrollPane(tabServicos), BorderLayout.CENTER);
        JPanel tabelas = new JPanel(new GridLayout(2, 1, 0, 8));
        tabelas.add(pecas);
        tabelas.add(servicos);

        // totais, alinhados à direita
        lblTotal.setFont(lblTotal.getFont().deriveFont(Font.BOLD, 20f));
        lblTotal.setForeground(new Color(31, 63, 102));
        Util.aoDigitar(txtDesconto, this::recalcular);
        JPanel totais = new JPanel(new GridLayout(0, 1, 0, 4));
        totais.add(linhaDireita(new JLabel("Total das peças:"), lblTotalPecas));
        totais.add(linhaDireita(new JLabel("Total da mão de obra:"), lblTotalServicos));
        totais.add(linhaDireita(new JLabel("Desconto (R$):"), txtDesconto));
        totais.add(linhaDireita(new JLabel("TOTAL A PAGAR:"), lblTotal));

        painel.add(norte, BorderLayout.NORTH);
        painel.add(tabelas, BorderLayout.CENTER);
        painel.add(totais, BorderLayout.SOUTH);
        return painel;
    }

    private JPanel montarPagamento() {
        JPanel painel = Util.painelComTitulo("Pagamento", new BorderLayout(0, 10));
        painel.setPreferredSize(new Dimension(360, 100));

        // formas de pagamento (apenas uma pode ficar marcada)
        JPanel formas = new JPanel(new GridLayout(0, 1, 0, 2));
        formas.add(new JLabel("Forma de pagamento:"));
        ButtonGroup grupo = new ButtonGroup();
        FormaPagamento[] valores = FormaPagamento.values();
        for (int i = 0; i < valores.length; i++) {
            radios[i] = new JRadioButton(valores[i].getDescricao());
            radios[i].addActionListener(e -> formaMudou());
            grupo.add(radios[i]);
            formas.add(radios[i]);
        }
        radios[FormaPagamento.PIX.ordinal()].setSelected(true);

        cmbParcelas.addActionListener(e -> { });
        Util.aoDigitar(txtRecebido, this::recalcular);

        JPanel campos = new JPanel(new GridLayout(0, 2, 6, 6));
        campos.add(new JLabel("Parcelas (crédito):"));
        campos.add(cmbParcelas);
        campos.add(new JLabel("Valor recebido (R$):"));
        campos.add(txtRecebido);
        campos.add(new JLabel("Troco:"));
        lblTroco.setFont(lblTroco.getFont().deriveFont(Font.BOLD));
        campos.add(lblTroco);

        JTextArea aviso = new JTextArea("Ao confirmar o pagamento, as peças da OS serão baixadas do estoque "
                + "automaticamente e a OS será marcada como Concluída.");
        aviso.setEditable(false);
        aviso.setLineWrap(true);
        aviso.setWrapStyleWord(true);
        aviso.setBackground(new Color(232, 241, 251));
        aviso.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(143, 179, 219)),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));

        btnConfirmar.setFont(btnConfirmar.getFont().deriveFont(Font.BOLD));
        btnConfirmar.addActionListener(e -> confirmar());
        btnLimpar.addActionListener(e -> {
            txtDesconto.setText("0,00");
            radios[FormaPagamento.PIX.ordinal()].setSelected(true);
            formaMudou();
        });

        JPanel meio = new JPanel(new BorderLayout(0, 10));
        meio.add(campos, BorderLayout.NORTH);
        JPanel caixaAviso = new JPanel(new BorderLayout());
        caixaAviso.add(aviso, BorderLayout.NORTH); // NORTH = ocupa só a altura necessária
        meio.add(caixaAviso, BorderLayout.CENTER);

        painel.add(formas, BorderLayout.NORTH);
        painel.add(meio, BorderLayout.CENTER);
        painel.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnConfirmar, btnLimpar), BorderLayout.SOUTH);
        return painel;
    }

    private void adicionar(JPanel painel, String titulo, JLabel valor) {
        JLabel rotulo = new JLabel(titulo);
        rotulo.setForeground(new Color(70, 70, 70));
        valor.setFont(valor.getFont().deriveFont(Font.BOLD));
        painel.add(rotulo);
        painel.add(valor);
    }

    private JPanel linhaDireita(JLabel rotulo, JComponent valor) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        p.add(rotulo);
        p.add(valor);
        return p;
    }

    // ====================== atualização ======================

    @Override
    public void atualizar() {
        OrdemServico atual = osAtual();
        List<OrdemServico> pendentes = new ArrayList<>();
        for (OrdemServico os : repo.getOrdens()) {
            if (!os.isFaturada()) {
                pendentes.add(os);
            }
        }
        pendentes.sort((a, b) -> b.getNumero() - a.getNumero());

        carregando = true;
        cmbOS.removeAllItems();
        for (OrdemServico os : pendentes) {
            cmbOS.addItem(os);
        }
        if (atual != null && pendentes.contains(atual)) {
            cmbOS.setSelectedItem(atual);
        }
        carregando = false;
        carregarOS();
    }

    /** Chamado pela janela quando o usuário clica em "Faturar" na aba de OS. */
    public void selecionarOS(OrdemServico os) {
        atualizar();
        cmbOS.setSelectedItem(os);
    }

    private OrdemServico osAtual() {
        return (OrdemServico) cmbOS.getSelectedItem();
    }

    private void carregarOS() {
        OrdemServico os = osAtual();
        modeloPecas.setRowCount(0);
        modeloServicos.setRowCount(0);
        if (os == null) {
            lblCliente.setText("Nenhuma OS pendente de faturamento");
            lblVeiculo.setText("-");
            lblMecanico.setText("-");
        } else {
            lblCliente.setText(os.getCliente().getNome());
            lblVeiculo.setText(os.getVeiculo().getPlaca() + " - " + os.getVeiculo().getMarca() + " "
                    + os.getVeiculo().getModelo());
            lblMecanico.setText(os.getMecanico().getNome());
            for (ItemPeca i : os.getItensPeca()) {
                modeloPecas.addRow(new Object[]{i.getPeca().getDescricao(), i.getQuantidade(),
                        Util.numero(i.getValorUnitario()), Util.numero(i.subtotal())});
            }
            for (ServicoMaoDeObra s : os.getServicos()) {
                modeloServicos.addRow(new Object[]{s.getDescricao(), Util.numero(s.getHoras()),
                        Util.numero(s.getValorHora()), Util.numero(s.subtotal())});
            }
            lblTotalPecas.setText(Util.moeda(os.calcularTotalPecas()));
            lblTotalServicos.setText(Util.moeda(os.calcularTotalServicos()));
        }
        btnConfirmar.setEnabled(os != null);
        txtDesconto.setText("0,00");
        formaMudou();
    }

    private FormaPagamento formaSelecionada() {
        FormaPagamento[] valores = FormaPagamento.values();
        for (int i = 0; i < radios.length; i++) {
            if (radios[i].isSelected()) {
                return valores[i];
            }
        }
        return FormaPagamento.PIX;
    }

    /** Liga/desliga os campos conforme a forma escolhida (parcelas só no crédito, troco só no dinheiro). */
    private void formaMudou() {
        FormaPagamento forma = formaSelecionada();
        cmbParcelas.setEnabled(forma == FormaPagamento.CREDITO);
        txtRecebido.setEnabled(forma == FormaPagamento.DINHEIRO);
        if (forma == FormaPagamento.DINHEIRO) {
            txtRecebido.setText(Util.numero(totalAPagar()));
        } else {
            txtRecebido.setText("");
        }
        recalcular();
    }

    /** Total da OS menos o desconto digitado (se o desconto for inválido, considera zero). */
    private double totalAPagar() {
        OrdemServico os = osAtual();
        if (os == null) {
            return 0;
        }
        double desconto = 0;
        try {
            if (!txtDesconto.getText().trim().isEmpty()) {
                desconto = Util.lerDouble(txtDesconto.getText());
            }
        } catch (NumberFormatException ex) {
            desconto = 0;
        }
        if (desconto < 0 || desconto > os.calcularTotal()) {
            desconto = 0;
        }
        return Math.round((os.calcularTotal() - desconto) * 100.0) / 100.0;
    }

    private void recalcular() {
        double total = totalAPagar();
        lblTotal.setText(Util.moeda(total));

        // lista de parcelas com o valor de cada uma
        int selecionada = Math.max(0, cmbParcelas.getSelectedIndex());
        cmbParcelas.removeAllItems();
        for (int n = 1; n <= 12; n++) {
            cmbParcelas.addItem(n + "x de " + Util.moeda(total / n));
        }
        cmbParcelas.setSelectedIndex(selecionada);

        double troco = 0;
        if (formaSelecionada() == FormaPagamento.DINHEIRO) {
            try {
                troco = Math.max(0, Util.lerDouble(txtRecebido.getText()) - total);
            } catch (NumberFormatException ex) {
                troco = 0;
            }
        }
        lblTroco.setText(Util.moeda(troco));
    }

    // ====================== confirmação ======================

    private void confirmar() {
        OrdemServico os = osAtual();
        if (os == null) {
            Util.erro(this, "Selecione uma OS para faturar.");
            return;
        }
        double subtotal = os.calcularTotal();
        double desconto = 0;
        try {
            if (!txtDesconto.getText().trim().isEmpty()) {
                desconto = Util.lerDouble(txtDesconto.getText());
            }
        } catch (NumberFormatException ex) {
            Util.erro(this, "Desconto inválido. Digite um valor como 10,00.");
            return;
        }
        if (desconto < 0 || desconto > subtotal) {
            Util.erro(this, "O desconto deve ficar entre R$ 0,00 e o total da OS (" + Util.moeda(subtotal) + ").");
            return;
        }
        double total = Math.round((subtotal - desconto) * 100.0) / 100.0;
        FormaPagamento forma = formaSelecionada();

        double recebido = total;
        if (forma == FormaPagamento.DINHEIRO) {
            try {
                recebido = Util.lerDouble(txtRecebido.getText());
            } catch (NumberFormatException ex) {
                Util.erro(this, "Informe o valor recebido em dinheiro.");
                return;
            }
            if (recebido < total) {
                Util.erro(this, "O valor recebido é menor que o total a pagar.");
                return;
            }
        }
        int parcelas = (forma == FormaPagamento.CREDITO) ? cmbParcelas.getSelectedIndex() + 1 : 1;

        if (!Util.confirmar(this, "Confirmar o pagamento de " + Util.moeda(total) + " via " + forma
                + (parcelas > 1 ? " em " + parcelas + "x" : "") + "?")) {
            return;
        }
        try {
            Faturamento f = repo.faturar(os, desconto, forma, parcelas, recebido);
            Util.info(this, "Pagamento registrado!\n\n"
                    + "OS #" + os.getNumero() + " concluída e faturada.\n"
                    + "Total: " + Util.moeda(f.getValorTotal()) + "  (" + forma + ")\n"
                    + (forma == FormaPagamento.DINHEIRO ? "Troco: " + Util.moeda(f.calcularTroco()) + "\n" : "")
                    + "As peças foram baixadas do estoque.");
            janela.atualizarTudo();
        } catch (IllegalStateException | IllegalArgumentException ex) {
            // por exemplo: estoque insuficiente para alguma peça
            Util.erro(this, ex.getMessage());
        }
    }
}
