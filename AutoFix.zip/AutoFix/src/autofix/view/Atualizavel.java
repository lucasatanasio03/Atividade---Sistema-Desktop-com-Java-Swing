package autofix.view;

/** Todo painel que precisa recarregar seus dados quando a aba é aberta implementa esta interface. */
public interface Atualizavel {
    void atualizar();
}
