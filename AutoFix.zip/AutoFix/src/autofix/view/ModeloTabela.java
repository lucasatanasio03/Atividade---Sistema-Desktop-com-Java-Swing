package autofix.view;

import javax.swing.table.DefaultTableModel;

/** Modelo de tabela somente leitura (o usuário não edita as células diretamente). */
public class ModeloTabela extends DefaultTableModel {

    public ModeloTabela(String... colunas) {
        super(colunas, 0);
    }

    @Override
    public boolean isCellEditable(int linha, int coluna) {
        return false;
    }
}
