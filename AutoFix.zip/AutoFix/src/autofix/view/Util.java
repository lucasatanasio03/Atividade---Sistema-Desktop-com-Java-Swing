package autofix.view;

import autofix.model.StatusOS;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Métodos auxiliares usados por todas as telas. */
public class Util {

    private static final DecimalFormat FORMATO =
            new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pt-BR")));
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static final Color COR_ZEBRA = new Color(245, 245, 245);

    private Util() {
    }

    // ---------- formatação e leitura de números ----------

    public static String moeda(double valor) {
        return "R$ " + FORMATO.format(valor);
    }

    public static String numero(double valor) {
        return FORMATO.format(valor);
    }

    public static String data(LocalDate data) {
        return data.format(FORMATO_DATA);
    }

    /** Aceita "1.234,56", "1234,56" e "1234.56". Lança NumberFormatException se for inválido. */
    public static double lerDouble(String texto) {
        String t = texto.trim().replace("R$", "").replace(" ", "");
        if (t.isEmpty()) {
            throw new NumberFormatException("vazio");
        }
        if (t.contains(",")) {
            t = t.replace(".", "").replace(",", ".");
        }
        return Double.parseDouble(t);
    }

    /** Aceita "48200" e "48.200". Lança NumberFormatException se for inválido. */
    public static int lerInt(String texto) {
        return Integer.parseInt(texto.trim().replace(".", ""));
    }

    public static String somenteDigitos(String texto) {
        return texto.replaceAll("[^0-9]", "");
    }

    // ---------- mensagens ----------

    public static void erro(Component pai, String mensagem) {
        JOptionPane.showMessageDialog(pai, mensagem, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    public static void info(Component pai, String mensagem) {
        JOptionPane.showMessageDialog(pai, mensagem, "AutoFix", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(Component pai, String mensagem) {
        int r = JOptionPane.showConfirmDialog(pai, mensagem, "Confirmação",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return r == JOptionPane.YES_OPTION;
    }

    // ---------- componentes ----------

    public static JTable criarTabela(ModeloTabela modelo) {
        JTable tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setFillsViewportHeight(true);
        tabela.getTableHeader().setReorderingAllowed(false);
        tabela.setGridColor(new Color(208, 208, 208));
        return tabela;
    }

    /** Define a largura preferida de cada coluna, na ordem. */
    public static void larguras(JTable tabela, int... larguras) {
        for (int i = 0; i < larguras.length; i++) {
            tabela.getColumnModel().getColumn(i).setPreferredWidth(larguras[i]);
        }
    }

    /** Alinha à direita as colunas indicadas (para números e valores em R$). */
    public static void alinharDireita(JTable tabela, int... colunas) {
        DefaultTableCellRenderer r = new DefaultTableCellRenderer();
        r.setHorizontalAlignment(SwingConstants.RIGHT);
        for (int c : colunas) {
            tabela.getColumnModel().getColumn(c).setCellRenderer(r);
        }
    }

    public static JPanel painelComTitulo(String titulo, LayoutManager layout) {
        JPanel painel = new JPanel(layout);
        painel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(titulo),
                BorderFactory.createEmptyBorder(4, 6, 6, 6)));
        return painel;
    }

    public static JPanel linhaDeBotoes(int alinhamento, JComponent... componentes) {
        JPanel p = new JPanel(new FlowLayout(alinhamento, 8, 0));
        for (JComponent c : componentes) {
            p.add(c);
        }
        return p;
    }

    /** Executa o código informado toda vez que o texto do campo mudar. */
    public static void aoDigitar(JTextField campo, Runnable acao) {
        campo.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { acao.run(); }
            public void removeUpdate(DocumentEvent e) { acao.run(); }
            public void changedUpdate(DocumentEvent e) { acao.run(); }
        });
    }

    // ---------- cores ----------

    public static Color fundoStatus(StatusOS status) {
        switch (status) {
            case ABERTA: return new Color(221, 235, 247);
            case EM_ANDAMENTO: return new Color(228, 225, 245);
            case AGUARDANDO_PECAS: return new Color(255, 243, 205);
            default: return new Color(217, 242, 222);
        }
    }

    public static Color textoStatus(StatusOS status) {
        switch (status) {
            case ABERTA: return new Color(31, 78, 121);
            case EM_ANDAMENTO: return new Color(59, 46, 138);
            case AGUARDANDO_PECAS: return new Color(138, 90, 0);
            default: return new Color(30, 107, 52);
        }
    }
}
