package autofix.view;

import autofix.dados.Repositorio;
import autofix.model.Cliente;
import autofix.model.Veiculo;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Aba 1: cadastro e gestão de clientes e seus veículos (relação 1:N). */
public class PainelClientes extends JPanel implements Atualizavel {

    private final Repositorio repo = Repositorio.getInstance();
    private final JanelaPrincipal janela;

    private final List<Cliente> exibidos = new ArrayList<>();

    private final JTextField txtBusca = new JTextField(16);
    private final ModeloTabela modeloClientes = new ModeloTabela("Nome", "CPF / CNPJ", "Telefone", "Veíc.");
    private final ModeloTabela modeloVeiculos = new ModeloTabela("Placa", "Marca / Modelo", "Ano", "Cor", "Km");
    private final JTable tabClientes = Util.criarTabela(modeloClientes);
    private final JTable tabVeiculos = Util.criarTabela(modeloVeiculos);

    private final JLabel lblNome = new JLabel("-");
    private final JLabel lblDocumento = new JLabel("-");
    private final JLabel lblTelefone = new JLabel("-");
    private final JLabel lblEmail = new JLabel("-");
    private final JLabel lblEndereco = new JLabel("-");

    private final JButton btnEditar = new JButton("Editar");
    private final JButton btnExcluir = new JButton("Excluir");
    private final JButton btnAddVeiculo = new JButton("Adicionar Veículo");
    private final JButton btnEditarVeiculo = new JButton("Editar Veículo");
    private final JButton btnRemoverVeiculo = new JButton("Remover Veículo");
    private final JButton btnAbrirOS = new JButton("Abrir OS para este cliente");

    public PainelClientes(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(12, 0));
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        add(montarPainelEsquerdo(), BorderLayout.WEST);
        add(montarPainelDireito(), BorderLayout.CENTER);

        tabClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                atualizarDetalhes();
            }
        });
        tabVeiculos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                atualizarBotoes();
            }
        });
        atualizar();
    }

    // ====================== montagem da tela ======================

    private JPanel montarPainelEsquerdo() {
        JPanel painel = Util.painelComTitulo("Clientes", new BorderLayout(0, 8));
        painel.setPreferredSize(new Dimension(520, 100));

        JButton btnBuscar = new JButton("Buscar");
        JButton btnLimpar = new JButton("Limpar");
        btnBuscar.addActionListener(e -> atualizar());
        txtBusca.addActionListener(e -> atualizar());
        btnLimpar.addActionListener(e -> {
            txtBusca.setText("");
            atualizar();
        });
        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        busca.add(new JLabel("Buscar:"));
        busca.add(txtBusca);
        busca.add(btnBuscar);
        busca.add(btnLimpar);
        busca.setToolTipText("Procure por nome, CPF/CNPJ, telefone ou placa");

        Util.larguras(tabClientes, 190, 120, 120, 40);
        Util.alinharDireita(tabClientes, 3);

        JButton btnNovo = new JButton("Novo Cliente");
        btnNovo.addActionListener(e -> novoCliente());
        btnEditar.addActionListener(e -> editarCliente());
        btnExcluir.addActionListener(e -> excluirCliente());

        painel.add(busca, BorderLayout.NORTH);
        painel.add(new JScrollPane(tabClientes), BorderLayout.CENTER);
        painel.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnNovo, btnEditar, btnExcluir), BorderLayout.SOUTH);
        return painel;
    }

    private JPanel montarPainelDireito() {
        JPanel painel = Util.painelComTitulo("Dados do Cliente", new BorderLayout(0, 10));

        JPanel dados = new JPanel(new GridLayout(0, 2, 6, 4));
        adicionarLinha(dados, "Nome:", lblNome);
        adicionarLinha(dados, "CPF / CNPJ:", lblDocumento);
        adicionarLinha(dados, "Telefone:", lblTelefone);
        adicionarLinha(dados, "E-mail:", lblEmail);
        adicionarLinha(dados, "Endereço:", lblEndereco);

        Util.larguras(tabVeiculos, 90, 170, 50, 80, 90);
        Util.alinharDireita(tabVeiculos, 2, 4);
        btnAddVeiculo.addActionListener(e -> adicionarVeiculo());
        btnEditarVeiculo.addActionListener(e -> editarVeiculo());
        btnRemoverVeiculo.addActionListener(e -> removerVeiculo());

        JPanel veiculos = Util.painelComTitulo("Veículos do cliente (um cliente pode ter vários)", new BorderLayout(0, 8));
        veiculos.add(new JScrollPane(tabVeiculos), BorderLayout.CENTER);
        veiculos.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnAddVeiculo, btnEditarVeiculo, btnRemoverVeiculo),
                BorderLayout.SOUTH);

        btnAbrirOS.addActionListener(e -> abrirOS());

        painel.add(dados, BorderLayout.NORTH);
        painel.add(veiculos, BorderLayout.CENTER);
        painel.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnAbrirOS), BorderLayout.SOUTH);
        return painel;
    }

    private void adicionarLinha(JPanel painel, String titulo, JLabel valor) {
        JLabel rotulo = new JLabel(titulo);
        rotulo.setForeground(new Color(70, 70, 70));
        valor.setFont(valor.getFont().deriveFont(Font.BOLD));
        painel.add(rotulo);
        painel.add(valor);
    }

    // ====================== atualização da tela ======================

    @Override
    public void atualizar() {
        Cliente selecionado = clienteSelecionado();
        String termo = txtBusca.getText().trim().toLowerCase();

        exibidos.clear();
        modeloClientes.setRowCount(0);
        for (Cliente c : repo.getClientes()) {
            if (combina(c, termo)) {
                exibidos.add(c);
                modeloClientes.addRow(new Object[]{c.getNome(), c.getCpfCnpj(), c.getTelefone(), c.getVeiculos().size()});
            }
        }
        int indice = exibidos.indexOf(selecionado);
        if (indice < 0 && !exibidos.isEmpty()) {
            indice = 0;
        }
        if (indice >= 0) {
            tabClientes.setRowSelectionInterval(indice, indice);
        }
        atualizarDetalhes();
    }

    private boolean combina(Cliente c, String termo) {
        if (termo.isEmpty()) {
            return true;
        }
        if (c.getNome().toLowerCase().contains(termo) || c.getCpfCnpj().toLowerCase().contains(termo)
                || c.getTelefone().toLowerCase().contains(termo)) {
            return true;
        }
        for (Veiculo v : c.getVeiculos()) {
            if (v.getPlaca().toLowerCase().contains(termo)) {
                return true;
            }
        }
        return false;
    }

    private void atualizarDetalhes() {
        Cliente c = clienteSelecionado();
        modeloVeiculos.setRowCount(0);
        if (c == null) {
            lblNome.setText("-");
            lblDocumento.setText("-");
            lblTelefone.setText("-");
            lblEmail.setText("-");
            lblEndereco.setText("-");
        } else {
            lblNome.setText(c.getNome());
            lblDocumento.setText(c.getCpfCnpj());
            lblTelefone.setText(c.getTelefone());
            lblEmail.setText(c.getEmail());
            lblEndereco.setText(c.getEndereco());
            for (Veiculo v : c.getVeiculos()) {
                modeloVeiculos.addRow(new Object[]{v.getPlaca(), v.getMarca() + " " + v.getModelo(),
                        v.getAno(), v.getCor(), Util.numero(v.getKm()).replace(",00", "")});
            }
            if (!c.getVeiculos().isEmpty()) {
                tabVeiculos.setRowSelectionInterval(0, 0);
            }
        }
        atualizarBotoes();
    }

    private void atualizarBotoes() {
        boolean temCliente = clienteSelecionado() != null;
        boolean temVeiculo = veiculoSelecionado() != null;
        btnEditar.setEnabled(temCliente);
        btnExcluir.setEnabled(temCliente);
        btnAddVeiculo.setEnabled(temCliente);
        btnEditarVeiculo.setEnabled(temVeiculo);
        btnRemoverVeiculo.setEnabled(temVeiculo);
        btnAbrirOS.setEnabled(temCliente);
    }

    private Cliente clienteSelecionado() {
        int linha = tabClientes.getSelectedRow();
        return (linha >= 0 && linha < exibidos.size()) ? exibidos.get(linha) : null;
    }

    private Veiculo veiculoSelecionado() {
        Cliente c = clienteSelecionado();
        int linha = tabVeiculos.getSelectedRow();
        if (c == null || linha < 0 || linha >= c.getVeiculos().size()) {
            return null;
        }
        return c.getVeiculos().get(linha);
    }

    private void selecionar(Cliente c) {
        int indice = exibidos.indexOf(c);
        if (indice >= 0) {
            tabClientes.setRowSelectionInterval(indice, indice);
        }
    }

    // ====================== ações dos botões ======================

    private void novoCliente() {
        Cliente novo = formularioCliente(null);
        if (novo != null) {
            txtBusca.setText("");
            atualizar();
            selecionar(novo);
            janela.atualizarTudo();
        }
    }

    private void editarCliente() {
        Cliente c = clienteSelecionado();
        if (c != null && formularioCliente(c) != null) {
            atualizar();
            janela.atualizarTudo();
        }
    }

    private void excluirCliente() {
        Cliente c = clienteSelecionado();
        if (c == null || !Util.confirmar(this, "Excluir o cliente " + c.getNome() + " e seus veículos?")) {
            return;
        }
        try {
            repo.removerCliente(c);
            atualizar();
        } catch (IllegalStateException ex) {
            Util.erro(this, ex.getMessage());
        }
    }

    private void adicionarVeiculo() {
        Cliente c = clienteSelecionado();
        if (c != null && formularioVeiculo(c, null) != null) {
            atualizar();
            selecionar(c);
        }
    }

    private void editarVeiculo() {
        Cliente c = clienteSelecionado();
        Veiculo v = veiculoSelecionado();
        if (c != null && v != null && formularioVeiculo(c, v) != null) {
            atualizar();
        }
    }

    private void removerVeiculo() {
        Veiculo v = veiculoSelecionado();
        if (v == null || !Util.confirmar(this, "Remover o veículo " + v.getPlaca() + "?")) {
            return;
        }
        try {
            repo.removerVeiculo(v);
            atualizar();
        } catch (IllegalStateException ex) {
            Util.erro(this, ex.getMessage());
        }
    }

    private void abrirOS() {
        Cliente c = clienteSelecionado();
        if (c == null) {
            return;
        }
        if (c.getVeiculos().isEmpty()) {
            Util.erro(this, "Cadastre ao menos um veículo para este cliente antes de abrir uma OS.");
            return;
        }
        janela.novaOS(c);
    }

    // ====================== formulários (caixas de diálogo) ======================

    /** Se "existente" for null cria um cliente novo; senão edita o existente. Retorna null se cancelar. */
    private Cliente formularioCliente(Cliente existente) {
        JTextField nome = new JTextField(existente == null ? "" : existente.getNome(), 22);
        JTextField documento = new JTextField(existente == null ? "" : existente.getCpfCnpj());
        JTextField telefone = new JTextField(existente == null ? "" : existente.getTelefone());
        JTextField email = new JTextField(existente == null ? "" : existente.getEmail());
        JTextField endereco = new JTextField(existente == null ? "" : existente.getEndereco());

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Nome completo:"));
        form.add(nome);
        form.add(new JLabel("CPF (11 dígitos) ou CNPJ (14):"));
        form.add(documento);
        form.add(new JLabel("Telefone:"));
        form.add(telefone);
        form.add(new JLabel("E-mail:"));
        form.add(email);
        form.add(new JLabel("Endereço:"));
        form.add(endereco);

        while (true) {
            int resposta = JOptionPane.showConfirmDialog(this, form,
                    existente == null ? "Novo Cliente" : "Editar Cliente",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (resposta != JOptionPane.OK_OPTION) {
                return null;
            }
            String erro = validarCliente(existente, nome.getText().trim(), documento.getText().trim());
            if (erro != null) {
                Util.erro(this, erro);
                continue; // volta a mostrar o formulário com o que já foi digitado
            }
            Cliente c = existente;
            if (c == null) {
                c = new Cliente(nome.getText().trim(), documento.getText().trim(), telefone.getText().trim(),
                        email.getText().trim(), endereco.getText().trim());
                repo.adicionarCliente(c);
            } else {
                c.setNome(nome.getText().trim());
                c.setCpfCnpj(documento.getText().trim());
                c.setTelefone(telefone.getText().trim());
                c.setEmail(email.getText().trim());
                c.setEndereco(endereco.getText().trim());
            }
            return c;
        }
    }

    private String validarCliente(Cliente existente, String nome, String documento) {
        if (nome.isEmpty()) {
            return "Informe o nome do cliente.";
        }
        String digitos = Util.somenteDigitos(documento);
        if (digitos.length() != 11 && digitos.length() != 14) {
            return "Informe um CPF com 11 dígitos ou um CNPJ com 14 dígitos.";
        }
        Cliente outro = repo.buscarClientePorDocumento(digitos);
        if (outro != null && outro != existente) {
            return "Já existe um cliente cadastrado com este CPF/CNPJ (" + outro.getNome() + ").";
        }
        return null;
    }

    /** Se "existente" for null cria um veículo novo para o cliente; senão edita. Retorna null se cancelar. */
    private Veiculo formularioVeiculo(Cliente dono, Veiculo existente) {
        JTextField placa = new JTextField(existente == null ? "" : existente.getPlaca(), 12);
        JTextField marca = new JTextField(existente == null ? "" : existente.getMarca());
        JTextField modelo = new JTextField(existente == null ? "" : existente.getModelo());
        JTextField ano = new JTextField(existente == null ? "" : String.valueOf(existente.getAno()));
        JTextField cor = new JTextField(existente == null ? "" : existente.getCor());
        JTextField km = new JTextField(existente == null ? "" : String.valueOf(existente.getKm()));

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Cliente:"));
        form.add(new JLabel(dono.getNome()));
        form.add(new JLabel("Placa (ex.: ABC-1D23):"));
        form.add(placa);
        form.add(new JLabel("Marca:"));
        form.add(marca);
        form.add(new JLabel("Modelo:"));
        form.add(modelo);
        form.add(new JLabel("Ano:"));
        form.add(ano);
        form.add(new JLabel("Cor:"));
        form.add(cor);
        form.add(new JLabel("Quilometragem (km):"));
        form.add(km);

        while (true) {
            int resposta = JOptionPane.showConfirmDialog(this, form,
                    existente == null ? "Novo Veículo" : "Editar Veículo",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (resposta != JOptionPane.OK_OPTION) {
                return null;
            }
            String placaTexto = placa.getText().trim().toUpperCase();
            int anoNumero;
            int kmNumero;
            try {
                anoNumero = Util.lerInt(ano.getText());
                kmNumero = Util.lerInt(km.getText());
            } catch (NumberFormatException ex) {
                Util.erro(this, "Ano e quilometragem devem ser números inteiros.");
                continue;
            }
            String erro = validarVeiculo(existente, placaTexto, marca.getText().trim(),
                    modelo.getText().trim(), anoNumero, kmNumero);
            if (erro != null) {
                Util.erro(this, erro);
                continue;
            }
            Veiculo v = existente;
            if (v == null) {
                v = new Veiculo(placaTexto, marca.getText().trim(), modelo.getText().trim(), anoNumero,
                        cor.getText().trim(), kmNumero);
                repo.adicionarVeiculo(dono, v);
            } else {
                v.setPlaca(placaTexto);
                v.setMarca(marca.getText().trim());
                v.setModelo(modelo.getText().trim());
                v.setAno(anoNumero);
                v.setCor(cor.getText().trim());
                v.setKm(kmNumero);
            }
            return v;
        }
    }

    private String validarVeiculo(Veiculo existente, String placa, String marca, String modelo, int ano, int km) {
        if (!placa.matches("[A-Z]{3}-?[0-9][A-Z0-9][0-9]{2}")) {
            return "Placa inválida. Use o formato ABC-1234 ou ABC-1D23.";
        }
        if (marca.isEmpty() || modelo.isEmpty()) {
            return "Informe a marca e o modelo do veículo.";
        }
        if (ano < 1900 || ano > LocalDate.now().getYear() + 1) {
            return "Informe um ano válido.";
        }
        if (km < 0) {
            return "A quilometragem não pode ser negativa.";
        }
        Veiculo outro = repo.buscarVeiculoPorPlaca(placa);
        if (outro != null && outro != existente) {
            return "Já existe um veículo cadastrado com esta placa.";
        }
        return null;
    }
}
