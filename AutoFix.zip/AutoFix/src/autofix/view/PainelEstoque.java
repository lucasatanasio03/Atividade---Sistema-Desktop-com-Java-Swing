package autofix.view;

import autofix.dados.Repositorio;
import autofix.model.Peca;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/** Aba 2: controle de estoque de peças, com alerta de estoque baixo. */
public class PainelEstoque extends JPanel implements Atualizavel {

    private static final String TODAS = "Todas";

    private final Repositorio repo = Repositorio.getInstance();
    private final JanelaPrincipal janela;

    private final List<Peca> exibidas = new ArrayList<>();

    private final JTextField txtBusca = new JTextField(18);
    private final JComboBox<String> cmbCategoria = new JComboBox<>();
    private final JCheckBox chkSomenteBaixo = new JCheckBox("Somente estoque baixo");
    private final JLabel lblAlerta = new JLabel();
    private final JLabel lblContagem = new JLabel();
    private final ModeloTabela modelo = new ModeloTabela("Código", "Descrição", "Categoria", "Qtd.", "Mín.",
            "Custo (R$)", "Venda (R$)", "Situação");
    private final JTable tabela = Util.criarTabela(modelo);
    private final JButton btnEditar = new JButton("Editar Peça");
    private final JButton btnExcluir = new JButton("Excluir Peça");

    private boolean carregando = false; // evita recarregar a tabela enquanto o combo é preenchido

    public PainelEstoque(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(0, 10));
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        add(montarTopo(), BorderLayout.NORTH);

        tabela.setDefaultRenderer(Object.class, new RenderizadorEstoque());
        Util.larguras(tabela, 80, 300, 120, 50, 50, 90, 90, 90);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel rodape = new JPanel(new BorderLayout());
        btnEditar.addActionListener(e -> editarPeca());
        btnExcluir.addActionListener(e -> excluirPeca());
        rodape.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnEditar, btnExcluir), BorderLayout.WEST);
        rodape.add(lblContagem, BorderLayout.EAST);
        add(rodape, BorderLayout.SOUTH);

        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                atualizarBotoes();
            }
        });
        atualizar();
    }

    private JPanel montarTopo() {
        JButton btnNova = new JButton("Nova Peça");
        JButton btnEntrada = new JButton("Entrada de Estoque");
        btnNova.addActionListener(e -> novaPeca());
        btnEntrada.addActionListener(e -> entradaDeEstoque());

        txtBusca.addActionListener(e -> atualizar());
        Util.aoDigitar(txtBusca, this::atualizar);
        cmbCategoria.addActionListener(e -> {
            if (!carregando) {
                atualizar();
            }
        });
        chkSomenteBaixo.addActionListener(e -> atualizar());

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filtros.add(new JLabel("Buscar peça:"));
        filtros.add(txtBusca);
        filtros.add(new JLabel("Categoria:"));
        filtros.add(cmbCategoria);
        filtros.add(chkSomenteBaixo);
        filtros.add(Box.createHorizontalStrut(20));
        filtros.add(btnNova);
        filtros.add(btnEntrada);

        lblAlerta.setOpaque(true);
        lblAlerta.setBackground(new Color(255, 243, 205));
        lblAlerta.setForeground(new Color(122, 82, 0));
        lblAlerta.setFont(lblAlerta.getFont().deriveFont(Font.BOLD));
        lblAlerta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(224, 184, 64)),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));

        JPanel topo = new JPanel(new BorderLayout(0, 8));
        topo.add(filtros, BorderLayout.NORTH);
        topo.add(lblAlerta, BorderLayout.CENTER);
        return topo;
    }

    // ====================== atualização ======================

    @Override
    public void atualizar() {
        recarregarCategorias();

        Peca selecionada = pecaSelecionada();
        String termo = txtBusca.getText().trim().toLowerCase();
        Object categoria = cmbCategoria.getSelectedItem();

        exibidas.clear();
        modelo.setRowCount(0);
        int baixas = 0;
        int zeradas = 0;
        for (Peca p : repo.getPecas()) {
            if (p.estoqueZerado()) {
                zeradas++;
            } else if (p.estoqueBaixo()) {
                baixas++;
            }
            boolean passaBusca = termo.isEmpty() || p.getCodigo().toLowerCase().contains(termo)
                    || p.getDescricao().toLowerCase().contains(termo);
            boolean passaCategoria = categoria == null || TODAS.equals(categoria)
                    || p.getCategoria().equals(categoria);
            boolean passaBaixo = !chkSomenteBaixo.isSelected() || p.estoqueBaixo();
            if (passaBusca && passaCategoria && passaBaixo) {
                exibidas.add(p);
                modelo.addRow(new Object[]{p.getCodigo(), p.getDescricao(), p.getCategoria(), p.getQuantidade(),
                        p.getQuantidadeMinima(), Util.numero(p.getPrecoCusto()), Util.numero(p.getPrecoVenda()),
                        p.getSituacao()});
            }
        }

        int abaixo = baixas + zeradas;
        lblAlerta.setVisible(abaixo > 0);
        lblAlerta.setText("Atenção: " + abaixo + (abaixo == 1 ? " peça está" : " peças estão")
                + " com estoque abaixo do mínimo (" + baixas + " baixo, " + zeradas + " zerado).");
        lblContagem.setText(exibidas.size() + " item(ns) listado(s)");

        int indice = exibidas.indexOf(selecionada);
        if (indice >= 0) {
            tabela.setRowSelectionInterval(indice, indice);
        }
        atualizarBotoes();
    }

    private void recarregarCategorias() {
        Object atual = cmbCategoria.getSelectedItem();
        TreeSet<String> categorias = new TreeSet<>();
        for (Peca p : repo.getPecas()) {
            categorias.add(p.getCategoria());
        }
        carregando = true;
        cmbCategoria.removeAllItems();
        cmbCategoria.addItem(TODAS);
        for (String c : categorias) {
            cmbCategoria.addItem(c);
        }
        cmbCategoria.setSelectedItem(atual != null && (TODAS.equals(atual) || categorias.contains(atual)) ? atual : TODAS);
        carregando = false;
    }

    private void atualizarBotoes() {
        boolean tem = pecaSelecionada() != null;
        btnEditar.setEnabled(tem);
        btnExcluir.setEnabled(tem);
    }

    private Peca pecaSelecionada() {
        int linha = tabela.getSelectedRow();
        return (linha >= 0 && linha < exibidas.size()) ? exibidas.get(linha) : null;
    }

    // ====================== ações ======================

    private void novaPeca() {
        if (formularioPeca(null) != null) {
            atualizar();
            janela.atualizarTudo();
        }
    }

    private void editarPeca() {
        Peca p = pecaSelecionada();
        if (p != null && formularioPeca(p) != null) {
            atualizar();
            janela.atualizarTudo();
        }
    }

    private void excluirPeca() {
        Peca p = pecaSelecionada();
        if (p == null || !Util.confirmar(this, "Excluir a peça " + p + "?")) {
            return;
        }
        try {
            repo.removerPeca(p);
            atualizar();
        } catch (IllegalStateException ex) {
            Util.erro(this, ex.getMessage());
        }
    }

    private void entradaDeEstoque() {
        if (repo.getPecas().isEmpty()) {
            Util.erro(this, "Cadastre uma peça antes de registrar uma entrada.");
            return;
        }
        JComboBox<Peca> cmbPeca = new JComboBox<>(repo.getPecas().toArray(new Peca[0]));
        Peca atual = pecaSelecionada();
        if (atual != null) {
            cmbPeca.setSelectedItem(atual);
        }
        JSpinner spnQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, 99999, 1));

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Peça:"));
        form.add(cmbPeca);
        form.add(new JLabel("Quantidade que entrou:"));
        form.add(spnQuantidade);

        int resposta = JOptionPane.showConfirmDialog(this, form, "Entrada de Estoque",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resposta == JOptionPane.OK_OPTION) {
            Peca p = (Peca) cmbPeca.getSelectedItem();
            p.registrarEntrada((Integer) spnQuantidade.getValue());
            atualizar();
            janela.atualizarTudo();
        }
    }

    /** Se "existente" for null cria uma peça nova; senão edita a existente. Retorna null se cancelar. */
    private Peca formularioPeca(Peca existente) {
        JTextField codigo = new JTextField(existente == null ? "" : existente.getCodigo(), 18);
        JTextField descricao = new JTextField(existente == null ? "" : existente.getDescricao());
        JComboBox<String> categoria = new JComboBox<>();
        categoria.setEditable(true); // permite digitar uma categoria nova
        TreeSet<String> categorias = new TreeSet<>();
        for (Peca p : repo.getPecas()) {
            categorias.add(p.getCategoria());
        }
        for (String c : categorias) {
            categoria.addItem(c);
        }
        categoria.setSelectedItem(existente == null ? "" : existente.getCategoria());
        JTextField quantidade = new JTextField(existente == null ? "0" : String.valueOf(existente.getQuantidade()));
        JTextField minima = new JTextField(existente == null ? "0" : String.valueOf(existente.getQuantidadeMinima()));
        JTextField custo = new JTextField(existente == null ? "" : Util.numero(existente.getPrecoCusto()));
        JTextField venda = new JTextField(existente == null ? "" : Util.numero(existente.getPrecoVenda()));

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Código:"));
        form.add(codigo);
        form.add(new JLabel("Descrição:"));
        form.add(descricao);
        form.add(new JLabel("Categoria:"));
        form.add(categoria);
        form.add(new JLabel("Quantidade em estoque:"));
        form.add(quantidade);
        form.add(new JLabel("Quantidade mínima:"));
        form.add(minima);
        form.add(new JLabel("Preço de custo (R$):"));
        form.add(custo);
        form.add(new JLabel("Preço de venda (R$):"));
        form.add(venda);

        while (true) {
            int resposta = JOptionPane.showConfirmDialog(this, form,
                    existente == null ? "Nova Peça" : "Editar Peça",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (resposta != JOptionPane.OK_OPTION) {
                return null;
            }
            String cod = codigo.getText().trim();
            String desc = descricao.getText().trim();
            String cat = String.valueOf(categoria.getSelectedItem()).trim();
            int qtd;
            int min;
            double precoCusto;
            double precoVenda;
            try {
                qtd = Util.lerInt(quantidade.getText());
                min = Util.lerInt(minima.getText());
                precoCusto = Util.lerDouble(custo.getText());
                precoVenda = Util.lerDouble(venda.getText());
            } catch (NumberFormatException ex) {
                Util.erro(this, "Quantidades devem ser números inteiros e preços devem ser números válidos (ex.: 49,90).");
                continue;
            }
            if (cod.isEmpty() || desc.isEmpty() || cat.isEmpty()) {
                Util.erro(this, "Preencha código, descrição e categoria.");
                continue;
            }
            if (qtd < 0 || min < 0 || precoCusto < 0 || precoVenda < 0) {
                Util.erro(this, "Os valores não podem ser negativos.");
                continue;
            }
            Peca outra = repo.buscarPecaPorCodigo(cod);
            if (outra != null && outra != existente) {
                Util.erro(this, "Já existe uma peça com este código.");
                continue;
            }
            Peca p = existente;
            if (p == null) {
                p = new Peca(cod, desc, cat, qtd, min, precoCusto, precoVenda);
                repo.adicionarPeca(p);
            } else {
                p.setCodigo(cod);
                p.setDescricao(desc);
                p.setCategoria(cat);
                p.setQuantidade(qtd);
                p.setQuantidadeMinima(min);
                p.setPrecoCusto(precoCusto);
                p.setPrecoVenda(precoVenda);
            }
            return p;
        }
    }

    // ====================== pintura das linhas ======================

    /** Pinta de amarelo as linhas com estoque baixo e de vermelho as zeradas. */
    private class RenderizadorEstoque extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object valor, boolean selecionada,
                                                       boolean foco, int linha, int coluna) {
            Component c = super.getTableCellRendererComponent(t, valor, selecionada, foco, linha, coluna);
            setHorizontalAlignment(coluna >= 3 && coluna <= 6 ? SwingConstants.RIGHT : SwingConstants.LEFT);
            if (!selecionada && linha < exibidas.size()) {
                Peca p = exibidas.get(linha);
                if (p.estoqueZerado()) {
                    setBackground(new Color(248, 215, 218));
                    setForeground(new Color(155, 28, 28));
                } else if (p.estoqueBaixo()) {
                    setBackground(new Color(255, 243, 205));
                    setForeground(new Color(122, 82, 0));
                } else {
                    setBackground(linha % 2 == 0 ? Color.WHITE : Util.COR_ZEBRA);
                    setForeground(Color.BLACK);
                }
                if (coluna == 7) {
                    setFont(getFont().deriveFont(Font.BOLD));
                }
            }
            return c;
        }
    }
}
