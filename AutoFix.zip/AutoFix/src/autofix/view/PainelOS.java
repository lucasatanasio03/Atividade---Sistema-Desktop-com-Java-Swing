package autofix.view;

import autofix.dados.Repositorio;
import autofix.model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Aba 3: abertura e acompanhamento de Ordens de Serviço (peças, mão de obra e status). */
public class PainelOS extends JPanel implements Atualizavel {

    private static final String TODAS = "Todas";

    private final Repositorio repo = Repositorio.getInstance();
    private final JanelaPrincipal janela;

    private final List<OrdemServico> exibidas = new ArrayList<>();

    // lista de OS (lado esquerdo)
    private final JComboBox<Object> cmbFiltroStatus = new JComboBox<>();
    private final JTextField txtBusca = new JTextField(12);
    private final ModeloTabela modeloOS = new ModeloTabela("Nº", "Cliente", "Placa", "Status", "Total (R$)");
    private final JTable tabOS = Util.criarTabela(modeloOS);
    private final JButton btnExcluirOS = new JButton("Excluir OS");

    // detalhes (lado direito)
    private final JLabel lblNumero = new JLabel("-");
    private final JLabel lblCliente = new JLabel("-");
    private final JLabel lblVeiculo = new JLabel("-");
    private final JLabel lblMecanico = new JLabel("-");
    private final JLabel lblKm = new JLabel("-");
    private final JTextArea txtProblema = new JTextArea(2, 30);
    private final JComboBox<StatusOS> cmbStatus = new JComboBox<>(StatusOS.values());
    private final JLabel lblFaturada = new JLabel(" ");
    private final ModeloTabela modeloPecas = new ModeloTabela("Código", "Peça", "Qtd.", "Unit. (R$)", "Subtotal (R$)");
    private final JTable tabPecas = Util.criarTabela(modeloPecas);
    private final ModeloTabela modeloServicos = new ModeloTabela("Serviço", "Horas", "Valor/h (R$)", "Subtotal (R$)");
    private final JTable tabServicos = Util.criarTabela(modeloServicos);
    private final JLabel lblTotais = new JLabel(" ");

    private final JButton btnEditarOS = new JButton("Editar OS");
    private final JButton btnAddPeca = new JButton("Adicionar Peça");
    private final JButton btnRemoverPeca = new JButton("Remover Peça");
    private final JButton btnAddServico = new JButton("Adicionar Serviço");
    private final JButton btnRemoverServico = new JButton("Remover Serviço");
    private final JButton btnFaturar = new JButton("Faturar");

    private boolean atualizandoTela = false; // evita que o combo de status dispare ações ao ser preenchido

    public PainelOS(JanelaPrincipal janela) {
        this.janela = janela;
        setLayout(new BorderLayout(12, 0));
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        add(montarPainelLista(), BorderLayout.WEST);
        add(montarPainelDetalhes(), BorderLayout.CENTER);

        tabOS.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                atualizarDetalhes();
            }
        });
        cmbStatus.addActionListener(e -> mudarStatus());
        atualizar();
    }

    // ====================== montagem da tela ======================

    private JPanel montarPainelLista() {
        JPanel painel = Util.painelComTitulo("Ordens de Serviço", new BorderLayout(0, 8));
        painel.setPreferredSize(new Dimension(520, 100));

        cmbFiltroStatus.addItem(TODAS);
        for (StatusOS s : StatusOS.values()) {
            cmbFiltroStatus.addItem(s);
        }
        cmbFiltroStatus.addActionListener(e -> recarregarLista(osSelecionada()));
        Util.aoDigitar(txtBusca, () -> recarregarLista(osSelecionada()));

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        filtros.add(new JLabel("Status:"));
        filtros.add(cmbFiltroStatus);
        filtros.add(new JLabel("Buscar:"));
        filtros.add(txtBusca);
        txtBusca.setToolTipText("Número da OS, cliente ou placa");

        tabOS.setDefaultRenderer(Object.class, new RenderizadorOS());
        Util.larguras(tabOS, 45, 125, 70, 150, 80);

        JButton btnNova = new JButton("Nova OS");
        btnNova.addActionListener(e -> novaOS(null));
        btnExcluirOS.addActionListener(e -> excluirOS());

        painel.add(filtros, BorderLayout.NORTH);
        painel.add(new JScrollPane(tabOS), BorderLayout.CENTER);
        painel.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnNova, btnExcluirOS), BorderLayout.SOUTH);
        return painel;
    }

    private JPanel montarPainelDetalhes() {
        JPanel painel = Util.painelComTitulo("Detalhes da OS selecionada", new BorderLayout(0, 8));

        // --- dados gerais ---
        JPanel linhaStatus = new JPanel(new BorderLayout(8, 0));
        JPanel numeroOS = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        adicionar(numeroOS, "Nº da OS:", lblNumero);
        JPanel escolhaStatus = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        escolhaStatus.add(new JLabel("Status:"));
        cmbStatus.setPreferredSize(new Dimension(170, 26));
        escolhaStatus.add(cmbStatus);
        linhaStatus.add(numeroOS, BorderLayout.WEST);
        linhaStatus.add(escolhaStatus, BorderLayout.EAST);

        JPanel dados = new JPanel(new GridLayout(0, 2, 8, 4));
        adicionar(dados, "Cliente:", lblCliente);
        adicionar(dados, "Veículo:", lblVeiculo);
        adicionar(dados, "Mecânico:", lblMecanico);
        adicionar(dados, "Entrada:", lblKm);

        JPanel blocoDados = new JPanel(new BorderLayout(0, 6));
        blocoDados.add(linhaStatus, BorderLayout.NORTH);
        blocoDados.add(dados, BorderLayout.CENTER);

        txtProblema.setEditable(false);
        txtProblema.setLineWrap(true);
        txtProblema.setWrapStyleWord(true);
        txtProblema.setBackground(getBackground());
        JPanel problema = new JPanel(new BorderLayout(6, 0));
        problema.add(new JLabel("Problema relatado:"), BorderLayout.WEST);
        problema.add(new JScrollPane(txtProblema), BorderLayout.CENTER);

        lblFaturada.setForeground(new Color(30, 107, 52));
        lblFaturada.setFont(lblFaturada.getFont().deriveFont(Font.BOLD));

        JPanel topo = new JPanel(new BorderLayout(0, 6));
        topo.add(blocoDados, BorderLayout.NORTH);
        topo.add(problema, BorderLayout.CENTER);
        topo.add(lblFaturada, BorderLayout.SOUTH);

        // --- peças ---
        Util.larguras(tabPecas, 70, 200, 40, 80, 90);
        Util.alinharDireita(tabPecas, 2, 3, 4);
        btnAddPeca.addActionListener(e -> adicionarPeca());
        btnRemoverPeca.addActionListener(e -> removerPeca());
        JPanel pecas = Util.painelComTitulo("Peças", new BorderLayout(0, 6));
        pecas.add(new JScrollPane(tabPecas), BorderLayout.CENTER);
        pecas.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnAddPeca, btnRemoverPeca), BorderLayout.SOUTH);

        // --- mão de obra ---
        Util.larguras(tabServicos, 220, 50, 90, 90);
        Util.alinharDireita(tabServicos, 1, 2, 3);
        btnAddServico.addActionListener(e -> adicionarServico());
        btnRemoverServico.addActionListener(e -> removerServico());
        JPanel servicos = Util.painelComTitulo("Mão de obra", new BorderLayout(0, 6));
        servicos.add(new JScrollPane(tabServicos), BorderLayout.CENTER);
        servicos.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnAddServico, btnRemoverServico), BorderLayout.SOUTH);

        JPanel centro = new JPanel(new GridLayout(2, 1, 0, 8));
        centro.add(pecas);
        centro.add(servicos);

        // --- rodapé ---
        lblTotais.setFont(lblTotais.getFont().deriveFont(Font.BOLD, 14f));
        btnEditarOS.addActionListener(e -> editarOS());
        btnFaturar.addActionListener(e -> faturar());
        JPanel rodape = new JPanel(new BorderLayout(0, 6));
        JPanel linhaTotais = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        linhaTotais.add(lblTotais);
        rodape.add(linhaTotais, BorderLayout.NORTH);
        rodape.add(Util.linhaDeBotoes(FlowLayout.LEFT, btnFaturar, btnEditarOS), BorderLayout.CENTER);

        painel.add(topo, BorderLayout.NORTH);
        painel.add(centro, BorderLayout.CENTER);
        painel.add(rodape, BorderLayout.SOUTH);
        return painel;
    }

    private void adicionar(JPanel painel, String titulo, JLabel valor) {
        JLabel rotulo = new JLabel(titulo);
        rotulo.setForeground(new Color(70, 70, 70));
        valor.setFont(valor.getFont().deriveFont(Font.BOLD));
        painel.add(rotulo);
        painel.add(valor);
    }

    // ====================== atualização da tela ======================

    @Override
    public void atualizar() {
        recarregarLista(osSelecionada());
    }

    /** Recarrega a lista da esquerda aplicando os filtros e tenta manter a OS indicada selecionada. */
    private void recarregarLista(OrdemServico manter) {
        Object filtro = cmbFiltroStatus.getSelectedItem();
        String termo = txtBusca.getText().trim().toLowerCase();

        exibidas.clear();
        for (OrdemServico os : repo.getOrdens()) {
            boolean passaStatus = !(filtro instanceof StatusOS) || os.getStatus() == filtro;
            boolean passaBusca = termo.isEmpty()
                    || String.valueOf(os.getNumero()).contains(termo)
                    || os.getCliente().getNome().toLowerCase().contains(termo)
                    || os.getVeiculo().getPlaca().toLowerCase().contains(termo);
            if (passaStatus && passaBusca) {
                exibidas.add(os);
            }
        }
        exibidas.sort((a, b) -> b.getNumero() - a.getNumero()); // mais recentes primeiro

        modeloOS.setRowCount(0);
        for (OrdemServico os : exibidas) {
            modeloOS.addRow(new Object[]{os.getNumero(), os.getCliente().getNome(), os.getVeiculo().getPlaca(),
                    os.getStatus().getDescricao(), Util.numero(os.calcularTotal())});
        }
        int indice = exibidas.indexOf(manter);
        if (indice < 0 && !exibidas.isEmpty()) {
            indice = 0;
        }
        if (indice >= 0) {
            tabOS.setRowSelectionInterval(indice, indice);
        }
        atualizarDetalhes();
    }

    private void atualizarDetalhes() {
        OrdemServico os = osSelecionada();
        atualizandoTela = true;
        modeloPecas.setRowCount(0);
        modeloServicos.setRowCount(0);

        if (os == null) {
            lblNumero.setText("-");
            lblCliente.setText("-");
            lblVeiculo.setText("-");
            lblMecanico.setText("-");
            lblKm.setText("-");
            txtProblema.setText("");
            lblFaturada.setText(" ");
            lblTotais.setText(" ");
        } else {
            lblNumero.setText("#" + os.getNumero());
            lblCliente.setText(os.getCliente().getNome());
            lblVeiculo.setText(os.getVeiculo().getPlaca() + " - " + os.getVeiculo().getModelo());
            lblMecanico.setText(os.getMecanico().getNome());
            lblKm.setText(Util.numero(os.getKmEntrada()).replace(",00", "") + " km  -  aberta em "
                    + Util.data(os.getDataAbertura()));
            txtProblema.setText(os.getProblemaRelatado());
            cmbStatus.setSelectedItem(os.getStatus());
            lblFaturada.setText(os.isFaturada()
                    ? "OS faturada em " + Util.data(os.getFaturamento().getDataPagamento()) + " - somente leitura"
                    : " ");
            for (ItemPeca item : os.getItensPeca()) {
                modeloPecas.addRow(new Object[]{item.getPeca().getCodigo(), item.getPeca().getDescricao(),
                        item.getQuantidade(), Util.numero(item.getValorUnitario()), Util.numero(item.subtotal())});
            }
            for (ServicoMaoDeObra s : os.getServicos()) {
                modeloServicos.addRow(new Object[]{s.getDescricao(), Util.numero(s.getHoras()),
                        Util.numero(s.getValorHora()), Util.numero(s.subtotal())});
            }
            lblTotais.setText("Peças: " + Util.moeda(os.calcularTotalPecas())
                    + "    Mão de obra: " + Util.moeda(os.calcularTotalServicos())
                    + "    TOTAL: " + Util.moeda(os.calcularTotal()));
        }
        atualizandoTela = false;
        atualizarBotoes();
    }

    private void atualizarBotoes() {
        OrdemServico os = osSelecionada();
        boolean tem = os != null;
        boolean editavel = tem && !os.isFaturada();
        cmbStatus.setEnabled(editavel);
        btnEditarOS.setEnabled(editavel);
        btnAddPeca.setEnabled(editavel);
        btnAddServico.setEnabled(editavel);
        btnRemoverPeca.setEnabled(editavel && !os.getItensPeca().isEmpty());
        btnRemoverServico.setEnabled(editavel && !os.getServicos().isEmpty());
        btnFaturar.setEnabled(editavel);
        btnExcluirOS.setEnabled(editavel);
    }

    private OrdemServico osSelecionada() {
        int linha = tabOS.getSelectedRow();
        return (linha >= 0 && linha < exibidas.size()) ? exibidas.get(linha) : null;
    }

    // ====================== ações ======================

    private void mudarStatus() {
        OrdemServico os = osSelecionada();
        if (atualizandoTela || os == null || os.isFaturada()) {
            return;
        }
        os.setStatus((StatusOS) cmbStatus.getSelectedItem());
        recarregarLista(os);
        janela.atualizarOutrasAbas(this);
    }

    /** Abre o formulário de nova OS. Se "clientePre" não for null, já vem com o cliente escolhido. */
    public void novaOS(Cliente clientePre) {
        if (repo.getClientes().isEmpty() || repo.getMecanicos().isEmpty()) {
            Util.erro(this, "Cadastre ao menos um cliente (com veículo) e um mecânico para abrir uma OS.");
            return;
        }
        OrdemServico nova = formularioOS(null, clientePre);
        if (nova != null) {
            cmbFiltroStatus.setSelectedItem(TODAS);
            txtBusca.setText("");
            recarregarLista(nova);
            janela.atualizarOutrasAbas(this);
        }
    }

    private void editarOS() {
        OrdemServico os = osSelecionada();
        if (os != null && formularioOS(os, null) != null) {
            recarregarLista(os);
        }
    }

    private void excluirOS() {
        OrdemServico os = osSelecionada();
        if (os == null || !Util.confirmar(this, "Excluir a OS #" + os.getNumero() + "?")) {
            return;
        }
        try {
            repo.removerOS(os);
            recarregarLista(null);
            janela.atualizarOutrasAbas(this);
        } catch (IllegalStateException ex) {
            Util.erro(this, ex.getMessage());
        }
    }

    private void faturar() {
        OrdemServico os = osSelecionada();
        if (os == null) {
            return;
        }
        if (os.getItensPeca().isEmpty() && os.getServicos().isEmpty()) {
            Util.erro(this, "Adicione ao menos uma peça ou um serviço antes de faturar.");
            return;
        }
        janela.faturar(os);
    }

    private void adicionarPeca() {
        OrdemServico os = osSelecionada();
        if (os == null || os.isFaturada()) {
            return;
        }
        if (repo.getPecas().isEmpty()) {
            Util.erro(this, "Não há peças cadastradas no estoque.");
            return;
        }
        JComboBox<Peca> cmbPeca = new JComboBox<>(repo.getPecas().toArray(new Peca[0]));
        cmbPeca.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object valor, int indice,
                                                          boolean selecionado, boolean foco) {
                super.getListCellRendererComponent(lista, valor, indice, selecionado, foco);
                if (valor instanceof Peca) {
                    Peca p = (Peca) valor;
                    setText(p.getCodigo() + " - " + p.getDescricao() + "  (estoque: " + p.getQuantidade() + ")");
                }
                return this;
            }
        });
        JSpinner spnQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, 9999, 1));

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Peça:"));
        form.add(cmbPeca);
        form.add(new JLabel("Quantidade:"));
        form.add(spnQuantidade);

        int resposta = JOptionPane.showConfirmDialog(this, form, "Adicionar Peça à OS #" + os.getNumero(),
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resposta != JOptionPane.OK_OPTION) {
            return;
        }
        Peca peca = (Peca) cmbPeca.getSelectedItem();
        int quantidade = (Integer) spnQuantidade.getValue();
        int necessario = os.quantidadeDaPeca(peca) + quantidade;

        if (necessario > peca.getQuantidade()) {
            boolean marcar = Util.confirmar(this, "Estoque insuficiente da peça " + peca + ".\n"
                    + "Disponível: " + peca.getQuantidade() + "  |  Necessário na OS: " + necessario + "\n\n"
                    + "Adicionar mesmo assim e marcar a OS como \"Aguardando Peças\"?");
            if (!marcar) {
                return;
            }
            os.adicionarPeca(peca, quantidade);
            os.setStatus(StatusOS.AGUARDANDO_PECAS);
        } else {
            os.adicionarPeca(peca, quantidade);
        }
        recarregarLista(os);
        janela.atualizarOutrasAbas(this);
    }

    private void removerPeca() {
        OrdemServico os = osSelecionada();
        int linha = tabPecas.getSelectedRow();
        if (os == null || linha < 0 || linha >= os.getItensPeca().size()) {
            Util.erro(this, "Selecione a peça que deseja remover na tabela.");
            return;
        }
        os.removerItemPeca(os.getItensPeca().get(linha));
        recarregarLista(os);
    }

    private void adicionarServico() {
        OrdemServico os = osSelecionada();
        if (os == null || os.isFaturada()) {
            return;
        }
        JTextField descricao = new JTextField(20);
        JTextField horas = new JTextField("1,0");
        JTextField valorHora = new JTextField("90,00");

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Serviço:"));
        form.add(descricao);
        form.add(new JLabel("Horas:"));
        form.add(horas);
        form.add(new JLabel("Valor da hora (R$):"));
        form.add(valorHora);

        while (true) {
            int resposta = JOptionPane.showConfirmDialog(this, form, "Adicionar Serviço à OS #" + os.getNumero(),
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (resposta != JOptionPane.OK_OPTION) {
                return;
            }
            double h;
            double v;
            try {
                h = Util.lerDouble(horas.getText());
                v = Util.lerDouble(valorHora.getText());
            } catch (NumberFormatException ex) {
                Util.erro(this, "Horas e valor da hora devem ser números válidos (ex.: 1,5 e 90,00).");
                continue;
            }
            if (descricao.getText().trim().isEmpty() || h <= 0 || v <= 0) {
                Util.erro(this, "Informe a descrição e valores maiores que zero.");
                continue;
            }
            os.adicionarServico(new ServicoMaoDeObra(descricao.getText().trim(), h, v));
            recarregarLista(os);
            return;
        }
    }

    private void removerServico() {
        OrdemServico os = osSelecionada();
        int linha = tabServicos.getSelectedRow();
        if (os == null || linha < 0 || linha >= os.getServicos().size()) {
            Util.erro(this, "Selecione o serviço que deseja remover na tabela.");
            return;
        }
        os.removerServico(os.getServicos().get(linha));
        recarregarLista(os);
    }

    // ====================== formulário da OS ======================

    /**
     * Se "existente" for null abre uma OS nova; senão edita mecânico, km e problema
     * (cliente e veículo não mudam depois que a OS é aberta). Retorna null se cancelar.
     */
    private OrdemServico formularioOS(OrdemServico existente, Cliente clientePre) {
        JComboBox<Cliente> cmbCliente = new JComboBox<>(repo.getClientes().toArray(new Cliente[0]));
        JComboBox<Veiculo> cmbVeiculo = new JComboBox<>();
        JComboBox<Mecanico> cmbMecanico = new JComboBox<>(repo.getMecanicos().toArray(new Mecanico[0]));
        JTextField txtKm = new JTextField(10);
        JTextArea txtProblemaForm = new JTextArea(3, 22);
        txtProblemaForm.setLineWrap(true);
        txtProblemaForm.setWrapStyleWord(true);

        // ao trocar o cliente, o combo de veículos mostra só os veículos dele (relação 1:N)
        Runnable carregarVeiculos = () -> {
            cmbVeiculo.removeAllItems();
            Cliente c = (Cliente) cmbCliente.getSelectedItem();
            if (c != null) {
                for (Veiculo v : c.getVeiculos()) {
                    cmbVeiculo.addItem(v);
                }
            }
        };
        cmbCliente.addActionListener(e -> carregarVeiculos.run());
        cmbVeiculo.addActionListener(e -> {
            Veiculo v = (Veiculo) cmbVeiculo.getSelectedItem();
            if (v != null && existente == null) {
                txtKm.setText(String.valueOf(v.getKm())); // sugere o km já cadastrado
            }
        });

        if (existente != null) {
            cmbCliente.setSelectedItem(existente.getCliente());
            carregarVeiculos.run();
            cmbVeiculo.setSelectedItem(existente.getVeiculo());
            cmbMecanico.setSelectedItem(existente.getMecanico());
            txtKm.setText(String.valueOf(existente.getKmEntrada()));
            txtProblemaForm.setText(existente.getProblemaRelatado());
            cmbCliente.setEnabled(false);
            cmbVeiculo.setEnabled(false);
        } else {
            if (clientePre != null) {
                cmbCliente.setSelectedItem(clientePre);
            }
            carregarVeiculos.run();
        }

        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Cliente:"));
        form.add(cmbCliente);
        form.add(new JLabel("Veículo:"));
        form.add(cmbVeiculo);
        form.add(new JLabel("Mecânico responsável:"));
        form.add(cmbMecanico);
        form.add(new JLabel("Km de entrada:"));
        form.add(txtKm);
        form.add(new JLabel("Problema relatado:"));
        form.add(new JScrollPane(txtProblemaForm));

        while (true) {
            int resposta = JOptionPane.showConfirmDialog(this, form,
                    existente == null ? "Nova Ordem de Serviço" : "Editar OS #" + existente.getNumero(),
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (resposta != JOptionPane.OK_OPTION) {
                return null;
            }
            Veiculo veiculo = (Veiculo) cmbVeiculo.getSelectedItem();
            Mecanico mecanico = (Mecanico) cmbMecanico.getSelectedItem();
            String problema = txtProblemaForm.getText().trim();
            int km;
            try {
                km = Util.lerInt(txtKm.getText());
            } catch (NumberFormatException ex) {
                Util.erro(this, "Informe a quilometragem de entrada (número inteiro).");
                continue;
            }
            if (veiculo == null) {
                Util.erro(this, "O cliente selecionado não possui veículos. Cadastre um veículo primeiro.");
                continue;
            }
            if (km < 0 || problema.isEmpty()) {
                Util.erro(this, "Informe uma quilometragem válida e descreva o problema relatado.");
                continue;
            }
            if (existente == null) {
                OrdemServico nova = repo.novaOS(veiculo, mecanico, km, problema);
                if (km > veiculo.getKm()) {
                    veiculo.setKm(km); // atualiza o km do veículo
                }
                return nova;
            }
            existente.setMecanico(mecanico);
            existente.setKmEntrada(km);
            existente.setProblemaRelatado(problema);
            return existente;
        }
    }

    // ====================== pintura da lista ======================

    /** Pinta a célula de status com a cor da situação da OS. */
    private class RenderizadorOS extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object valor, boolean selecionada,
                                                       boolean foco, int linha, int coluna) {
            Component c = super.getTableCellRendererComponent(t, valor, selecionada, foco, linha, coluna);
            setHorizontalAlignment(coluna == 4 ? SwingConstants.RIGHT : SwingConstants.LEFT);
            if (!selecionada && linha < exibidas.size()) {
                if (coluna == 3) {
                    StatusOS s = exibidas.get(linha).getStatus();
                    setBackground(Util.fundoStatus(s));
                    setForeground(Util.textoStatus(s));
                    setFont(getFont().deriveFont(Font.BOLD));
                } else {
                    setBackground(linha % 2 == 0 ? Color.WHITE : Util.COR_ZEBRA);
                    setForeground(Color.BLACK);
                }
            }
            return c;
        }
    }
}
