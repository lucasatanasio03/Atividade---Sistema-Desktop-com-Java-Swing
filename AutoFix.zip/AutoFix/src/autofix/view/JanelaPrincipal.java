package autofix.view;

import autofix.model.Cliente;
import autofix.model.OrdemServico;

import javax.swing.*;
import java.awt.*;

/** Janela principal do AutoFix: menu, 4 abas e barra de status. */
public class JanelaPrincipal extends JFrame {

    private final JTabbedPane abas = new JTabbedPane();
    private final PainelClientes painelClientes;
    private final PainelEstoque painelEstoque;
    private final PainelOS painelOS;
    private final PainelFaturamento painelFaturamento;

    public JanelaPrincipal() {
        super("AutoFix - Gestão de Oficina Mecânica");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(980, 640));
        setLocationRelativeTo(null);

        painelClientes = new PainelClientes(this);
        painelEstoque = new PainelEstoque(this);
        painelOS = new PainelOS(this);
        painelFaturamento = new PainelFaturamento(this);

        abas.addTab("Clientes e Veículos", painelClientes);
        abas.addTab("Estoque", painelEstoque);
        abas.addTab("Ordens de Serviço", painelOS);
        abas.addTab("Faturamento", painelFaturamento);
        // sempre que o usuário troca de aba, os dados daquela aba são recarregados
        abas.addChangeListener(e -> ((Atualizavel) abas.getSelectedComponent()).atualizar());

        setJMenuBar(criarMenu());
        add(abas, BorderLayout.CENTER);

        JLabel status = new JLabel("  Pronto   |   Os dados ficam na memória e voltam ao exemplo ao fechar o programa");
        status.setBorder(BorderFactory.createEmptyBorder(3, 4, 3, 4));
        add(status, BorderLayout.SOUTH);
    }

    private JMenuBar criarMenu() {
        JMenuBar barra = new JMenuBar();

        JMenu arquivo = new JMenu("Arquivo");
        JMenuItem sair = new JMenuItem("Sair");
        sair.addActionListener(e -> System.exit(0));
        arquivo.add(sair);

        JMenu cadastros = new JMenu("Cadastros");
        String[] nomes = {"Clientes e Veículos", "Estoque", "Ordens de Serviço", "Faturamento"};
        for (int i = 0; i < nomes.length; i++) {
            final int indice = i;
            JMenuItem item = new JMenuItem(nomes[i]);
            item.addActionListener(e -> abas.setSelectedIndex(indice));
            cadastros.add(item);
        }

        JMenu ajuda = new JMenu("Ajuda");
        JMenuItem sobre = new JMenuItem("Sobre");
        sobre.addActionListener(e -> Util.info(this,
                "AutoFix - Gestão de Oficina Mecânica\nProjeto acadêmico em Java Swing (Engenharia de Software)."));
        ajuda.add(sobre);

        barra.add(arquivo);
        barra.add(cadastros);
        barra.add(ajuda);
        return barra;
    }

    /** Vai para a aba de OS e abre o formulário de nova OS já com o cliente escolhido. */
    public void novaOS(Cliente cliente) {
        abas.setSelectedIndex(2);
        painelOS.novaOS(cliente);
    }

    /** Vai para a aba de Faturamento com a OS indicada selecionada. */
    public void faturar(OrdemServico os) {
        abas.setSelectedIndex(3);
        painelFaturamento.selecionarOS(os);
    }

    public void atualizarTudo() {
        painelClientes.atualizar();
        painelEstoque.atualizar();
        painelOS.atualizar();
        painelFaturamento.atualizar();
    }

    /** Atualiza as abas que dependem de OS, menos a que acabou de fazer a alteração. */
    public void atualizarOutrasAbas(Atualizavel origem) {
        if (origem != painelEstoque) {
            painelEstoque.atualizar();
        }
        if (origem != painelFaturamento) {
            painelFaturamento.atualizar();
        }
    }
}
