package autofix;

import autofix.view.JanelaPrincipal;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Ponto de entrada do sistema. */
public class Main {
    public static void main(String[] args) {
        // toda interface Swing deve ser criada na thread de eventos (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // se falhar, usa o visual padrão do Swing
            }
            new JanelaPrincipal().setVisible(true);
        });
    }
}
