package autofix.model;

import java.util.ArrayList;
import java.util.List;

/** Cliente da oficina. Um cliente possui vários veículos (relação 1:N). */
public class Cliente {
    private int id;
    private String nome;
    private String cpfCnpj;
    private String telefone;
    private String email;
    private String endereco;
    private final List<Veiculo> veiculos = new ArrayList<>();

    public Cliente(String nome, String cpfCnpj, String telefone, String email, String endereco) {
        this.nome = nome;
        this.cpfCnpj = cpfCnpj;
        this.telefone = telefone;
        this.email = email;
        this.endereco = endereco;
    }

    /** Vincula o veículo a este cliente (os dois lados da relação ficam consistentes). */
    public void adicionarVeiculo(Veiculo veiculo) {
        veiculo.setCliente(this);
        veiculos.add(veiculo);
    }

    public void removerVeiculo(Veiculo veiculo) {
        veiculos.remove(veiculo);
    }

    public List<Veiculo> getVeiculos() {
        return veiculos;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCpfCnpj() { return cpfCnpj; }
    public void setCpfCnpj(String cpfCnpj) { this.cpfCnpj = cpfCnpj; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    @Override
    public String toString() {
        return nome;
    }
}
