package autofix.model;

import java.time.LocalDate;

/** Registro do pagamento (fechamento de conta) de uma OS. */
public class Faturamento {
    private int id;
    private final OrdemServico ordemServico;
    private final LocalDate dataPagamento;
    private final double desconto;
    private final double valorTotal;
    private final double valorRecebido;
    private final FormaPagamento formaPagamento;
    private final int parcelas;

    public Faturamento(OrdemServico ordemServico, LocalDate dataPagamento, double desconto,
                       double valorTotal, double valorRecebido,
                       FormaPagamento formaPagamento, int parcelas) {
        this.ordemServico = ordemServico;
        this.dataPagamento = dataPagamento;
        this.desconto = desconto;
        this.valorTotal = valorTotal;
        this.valorRecebido = valorRecebido;
        this.formaPagamento = formaPagamento;
        this.parcelas = parcelas;
    }

    public double calcularTroco() {
        double troco = valorRecebido - valorTotal;
        return troco > 0 ? Math.round(troco * 100.0) / 100.0 : 0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public OrdemServico getOrdemServico() { return ordemServico; }
    public LocalDate getDataPagamento() { return dataPagamento; }
    public double getDesconto() { return desconto; }
    public double getValorTotal() { return valorTotal; }
    public double getValorRecebido() { return valorRecebido; }
    public FormaPagamento getFormaPagamento() { return formaPagamento; }
    public int getParcelas() { return parcelas; }
}
