package autofix.model;

/** Situações possíveis de uma Ordem de Serviço. */
public enum StatusOS {
    ABERTA("Aberta"),
    EM_ANDAMENTO("Em Andamento"),
    AGUARDANDO_PECAS("Aguardando Peças"),
    CONCLUIDA("Concluída");

    private final String descricao;

    StatusOS(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return descricao; // é o texto que aparece nos JComboBox e tabelas
    }
}
