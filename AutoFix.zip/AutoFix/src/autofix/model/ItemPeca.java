package autofix.model;

/**
 * Peça usada em uma OS. Guarda o valor unitário do momento da venda,
 * assim mudar o preço da peça depois não altera OS antigas.
 */
public class ItemPeca {
    private final Peca peca;
    private int quantidade;
    private final double valorUnitario;

    public ItemPeca(Peca peca, int quantidade, double valorUnitario) {
        this.peca = peca;
        this.quantidade = quantidade;
        this.valorUnitario = valorUnitario;
    }

    public double subtotal() {
        return quantidade * valorUnitario;
    }

    public Peca getPeca() { return peca; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public double getValorUnitario() { return valorUnitario; }
}
