package autofix.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Ordem de Serviço (OS): reúne veículo, mecânico, peças e mão de obra. */
public class OrdemServico {
    private final int numero;
    private LocalDate dataAbertura;
    private final Veiculo veiculo;
    private Mecanico mecanico;
    private int kmEntrada;
    private String problemaRelatado;
    private StatusOS status = StatusOS.ABERTA;
    private final List<ItemPeca> itensPeca = new ArrayList<>();
    private final List<ServicoMaoDeObra> servicos = new ArrayList<>();
    private Faturamento faturamento; // null enquanto a OS não foi paga

    public OrdemServico(int numero, Veiculo veiculo, Mecanico mecanico, int kmEntrada, String problemaRelatado) {
        this.numero = numero;
        this.dataAbertura = LocalDate.now();
        this.veiculo = veiculo;
        this.mecanico = mecanico;
        this.kmEntrada = kmEntrada;
        this.problemaRelatado = problemaRelatado;
    }

    public Cliente getCliente() {
        return veiculo.getCliente();
    }

    // ---------- peças e serviços ----------

    /** Se a peça já está na OS, apenas soma a quantidade. */
    public void adicionarPeca(Peca peca, int quantidade) {
        for (ItemPeca item : itensPeca) {
            if (item.getPeca() == peca) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                return;
            }
        }
        itensPeca.add(new ItemPeca(peca, quantidade, peca.getPrecoVenda()));
    }

    public int quantidadeDaPeca(Peca peca) {
        for (ItemPeca item : itensPeca) {
            if (item.getPeca() == peca) {
                return item.getQuantidade();
            }
        }
        return 0;
    }

    public void removerItemPeca(ItemPeca item) {
        itensPeca.remove(item);
    }

    public void adicionarServico(ServicoMaoDeObra servico) {
        servicos.add(servico);
    }

    public void removerServico(ServicoMaoDeObra servico) {
        servicos.remove(servico);
    }

    // ---------- totais ----------

    public double calcularTotalPecas() {
        double total = 0;
        for (ItemPeca item : itensPeca) {
            total += item.subtotal();
        }
        return arredondar(total);
    }

    public double calcularTotalServicos() {
        double total = 0;
        for (ServicoMaoDeObra s : servicos) {
            total += s.subtotal();
        }
        return arredondar(total);
    }

    public double calcularTotal() {
        return arredondar(calcularTotalPecas() + calcularTotalServicos());
    }

    private static double arredondar(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    // ---------- faturamento ----------

    public boolean isFaturada() {
        return faturamento != null;
    }

    /**
     * Fecha a conta: confere o estoque, dá baixa nas peças, conclui a OS
     * e cria o Faturamento. Se algo estiver errado lança exceção e NADA é alterado.
     */
    public Faturamento faturar(double desconto, FormaPagamento forma, int parcelas, double valorRecebido) {
        if (isFaturada()) {
            throw new IllegalStateException("Esta OS já foi faturada.");
        }
        if (itensPeca.isEmpty() && servicos.isEmpty()) {
            throw new IllegalStateException("A OS não possui peças nem serviços para faturar.");
        }
        double subtotal = calcularTotal();
        if (desconto < 0 || desconto > subtotal) {
            throw new IllegalArgumentException("O desconto deve estar entre R$ 0,00 e o total da OS.");
        }
        double total = arredondar(subtotal - desconto);
        if (forma == FormaPagamento.DINHEIRO && valorRecebido < total) {
            throw new IllegalStateException("O valor recebido é menor que o total a pagar.");
        }
        // 1º confere TODO o estoque, 2º dá baixa (assim não baixa pela metade)
        for (ItemPeca item : itensPeca) {
            Peca p = item.getPeca();
            if (item.getQuantidade() > p.getQuantidade()) {
                throw new IllegalStateException("Estoque insuficiente da peça " + p + " (disponível: "
                        + p.getQuantidade() + ", necessário: " + item.getQuantidade() + ").");
            }
        }
        for (ItemPeca item : itensPeca) {
            item.getPeca().darBaixa(item.getQuantidade());
        }
        status = StatusOS.CONCLUIDA;
        double recebido = (forma == FormaPagamento.DINHEIRO) ? valorRecebido : total;
        faturamento = new Faturamento(this, LocalDate.now(), desconto, total, recebido, forma, parcelas);
        return faturamento;
    }

    public int getNumero() { return numero; }
    public LocalDate getDataAbertura() { return dataAbertura; }
    public void setDataAbertura(LocalDate dataAbertura) { this.dataAbertura = dataAbertura; }
    public Veiculo getVeiculo() { return veiculo; }
    public Mecanico getMecanico() { return mecanico; }
    public void setMecanico(Mecanico mecanico) { this.mecanico = mecanico; }
    public int getKmEntrada() { return kmEntrada; }
    public void setKmEntrada(int kmEntrada) { this.kmEntrada = kmEntrada; }
    public String getProblemaRelatado() { return problemaRelatado; }
    public void setProblemaRelatado(String problemaRelatado) { this.problemaRelatado = problemaRelatado; }
    public StatusOS getStatus() { return status; }
    public void setStatus(StatusOS status) { this.status = status; }
    public List<ItemPeca> getItensPeca() { return itensPeca; }
    public List<ServicoMaoDeObra> getServicos() { return servicos; }
    public Faturamento getFaturamento() { return faturamento; }

    @Override
    public String toString() {
        return "OS #" + numero + " - " + getCliente().getNome() + " - " + veiculo.getPlaca();
    }
}
