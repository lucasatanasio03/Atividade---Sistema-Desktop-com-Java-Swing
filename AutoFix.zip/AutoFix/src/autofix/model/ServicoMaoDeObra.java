package autofix.model;

/** Serviço (mão de obra) executado em uma OS. */
public class ServicoMaoDeObra {
    private final String descricao;
    private final double horas;
    private final double valorHora;

    public ServicoMaoDeObra(String descricao, double horas, double valorHora) {
        this.descricao = descricao;
        this.horas = horas;
        this.valorHora = valorHora;
    }

    public double subtotal() {
        return horas * valorHora;
    }

    public String getDescricao() { return descricao; }
    public double getHoras() { return horas; }
    public double getValorHora() { return valorHora; }
}
