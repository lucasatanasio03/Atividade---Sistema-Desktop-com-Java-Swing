package autofix.model;

/** Formas de pagamento aceitas no fechamento da conta. */
public enum FormaPagamento {
    DINHEIRO("Dinheiro"),
    PIX("Pix"),
    DEBITO("Cartão de Débito"),
    CREDITO("Cartão de Crédito"),
    BOLETO("Boleto");

    private final String descricao;

    FormaPagamento(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
