package autofix.model;

/** Peça do estoque da oficina. */
public class Peca {
    private int id;
    private String codigo;
    private String descricao;
    private String categoria;
    private int quantidade;
    private int quantidadeMinima;
    private double precoCusto;
    private double precoVenda;

    public Peca(String codigo, String descricao, String categoria, int quantidade,
                int quantidadeMinima, double precoCusto, double precoVenda) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.categoria = categoria;
        this.quantidade = quantidade;
        this.quantidadeMinima = quantidadeMinima;
        this.precoCusto = precoCusto;
        this.precoVenda = precoVenda;
    }

    /** Estoque abaixo do mínimo (inclui o estoque zerado). */
    public boolean estoqueBaixo() {
        return quantidade < quantidadeMinima;
    }

    public boolean estoqueZerado() {
        return quantidade == 0;
    }

    /** Texto mostrado na coluna "Situação" da tabela de estoque. */
    public String getSituacao() {
        if (estoqueZerado()) {
            return "ZERADO";
        }
        if (estoqueBaixo()) {
            return "BAIXO";
        }
        return "OK";
    }

    public void registrarEntrada(int qtd) {
        if (qtd <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        quantidade += qtd;
    }

    public void darBaixa(int qtd) {
        if (qtd <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        if (qtd > quantidade) {
            throw new IllegalStateException("Estoque insuficiente da peça " + this
                    + " (disponível: " + quantidade + ", necessário: " + qtd + ").");
        }
        quantidade -= qtd;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public void setQuantidadeMinima(int quantidadeMinima) { this.quantidadeMinima = quantidadeMinima; }
    public double getPrecoCusto() { return precoCusto; }
    public void setPrecoCusto(double precoCusto) { this.precoCusto = precoCusto; }
    public double getPrecoVenda() { return precoVenda; }
    public void setPrecoVenda(double precoVenda) { this.precoVenda = precoVenda; }

    @Override
    public String toString() {
        return codigo + " - " + descricao;
    }
}
