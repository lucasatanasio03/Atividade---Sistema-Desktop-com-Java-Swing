# AutoFix - Gestão de Oficina Mecânica (Java Swing)

Projeto acadêmico de Engenharia de Software. Sistema desktop com 4 telas (abas):

1. **Clientes e Veículos** - cadastro, busca, edição e exclusão; um cliente tem vários veículos (1:N).
2. **Estoque** - cadastro de peças, entrada de estoque, filtros e alerta de estoque baixo/zerado.
3. **Ordens de Serviço** - abertura de OS, peças, mão de obra e controle de status
   (Aberta, Em Andamento, Aguardando Peças, Concluída).
4. **Faturamento** - resumo da OS, desconto, forma de pagamento, troco e baixa automática no estoque.

## Como executar

Pré-requisito: **JDK 11 ou superior** (testado com Java 21).

**Opção 1 - pronto (sem compilar):**

    java -jar AutoFix.jar

**Opção 2 - compilando:** execute `executar.bat` (Windows) ou `./executar.sh` (Linux/Mac).

**Opção 3 - IDE (NetBeans, IntelliJ, Eclipse):** crie um projeto Java, copie a pasta `src`
e execute a classe `autofix.Main`.

## Estrutura do projeto

    src/autofix/
      Main.java                    -> ponto de entrada
      model/                       -> classes do diagrama de classes (regras de negócio)
        Cliente, Veiculo, Mecanico, Peca, ItemPeca, ServicoMaoDeObra,
        OrdemServico, Faturamento, StatusOS (enum), FormaPagamento (enum)
      dados/
        Repositorio.java           -> "banco" em memória (listas) + dados de exemplo
      view/                        -> telas Swing
        JanelaPrincipal            -> JFrame com menu e as 4 abas (JTabbedPane)
        PainelClientes, PainelEstoque, PainelOS, PainelFaturamento
        Util, ModeloTabela, Atualizavel (apoio)

A organização segue a separação em camadas: **model** (o que o sistema é),
**dados** (onde ficam os dados) e **view** (o que o usuário vê).

## Regras de negócio implementadas

- CPF (11 dígitos) / CNPJ (14 dígitos) obrigatório e **único**; placa validada (ABC-1234 ou ABC-1D23) e **única**.
- Não é possível excluir cliente/veículo/peça que já está em uma OS.
- Ao adicionar uma peça sem estoque suficiente, o sistema avisa e oferece marcar a OS como **Aguardando Peças**.
- O valor unitário da peça é **gravado no item da OS** (mudar o preço depois não altera OS antigas).
- Ao **confirmar o pagamento**: confere o estoque de todas as peças, dá baixa, marca a OS como
  **Concluída** e cria o Faturamento. Se faltar peça, nada é alterado (erro claro para o usuário).
- Desconto entre R$ 0,00 e o total; dinheiro calcula o **troco**; crédito permite 1x a 12x.
- OS já faturada fica **somente leitura**.

## Conceitos de Java usados (para explicar na apresentação)

- Classes, atributos privados, getters/setters (encapsulamento) e construtores.
- `enum` com texto de exibição (`StatusOS`, `FormaPagamento`).
- Coleções: `List` / `ArrayList`; relação 1:N com lista dentro de `Cliente`.
- Exceções: `IllegalStateException` / `IllegalArgumentException` lançadas no model e tratadas na view.
- Swing: `JFrame`, `JTabbedPane`, `JTable` + `TableModel`, `JComboBox`, `JOptionPane`, layouts (`BorderLayout`, `GridLayout`, `FlowLayout`).
- Eventos com `ActionListener` (lambdas) e `ListSelectionListener`.
- Herança e interface: `JPanel` (herança) + `Atualizavel` (interface própria); renderizadores de célula (classes internas).
- Padrão **Singleton** em `Repositorio`.

## Limitações e próximos passos

- Os dados ficam **na memória**: ao fechar o programa voltam aos dados de exemplo.
  Próximo passo natural: persistir em banco (MySQL/SQLite via **JDBC**) usando o MER do projeto,
  criando classes DAO no lugar do `Repositorio`.
- Valores em `double` por simplicidade; em sistemas reais prefira `BigDecimal`.
- Sem login de usuário.
